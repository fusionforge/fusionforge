/*
 * Empty stubs for Microsoft's security package.
 * Javier Kohen, 2001.
 */

package com.ms.security;

public class PolicyEngine {
    public static void assertPermission(PermissionID pid) {
    }

    public static void checkPermission(PermissionID pid)
	throws SecurityException {
    }
}
