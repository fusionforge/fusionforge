package com.splendid.awtchat;

public interface HyperlinkReceiver {
    public void handleHyperlink(String link);
}