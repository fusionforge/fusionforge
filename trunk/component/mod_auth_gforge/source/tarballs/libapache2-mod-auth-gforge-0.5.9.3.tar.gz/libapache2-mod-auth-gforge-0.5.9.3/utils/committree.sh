#!/bin/bash

cd $1
svn update
list=`svn st | grep "^\?" | cut -c8- `
if [ "$list" != "" ]
then 
    svn st | grep "^\?" | cut -c8- | xargs svn add 
fi
svn commit -m"Initial Release"
