#! /usr/bin/php -f
<?php
/**
 * create_users.php 
 *
 * Francisco Gimeno <kikov@fco-gimeno.com>
 *
 * @version   $Id
 */

require ('squal_pre.php');

$first_letter = false;

if ($argc < 2 ) {
	echo "Usage ".$argv[0]." <path> <-f>\n";
	echo "-f   First Letter activated: users/a/abel\n";
	exit (0);
}
$upload_path = $argv[1];
if ($argv[2]=='-f')
   $first_letter = true;

if ($first_letter)
	echo "First Letter used\n";
else
	echo "First Letter not used\n";
/*

	This script create the gforge/upload directory for users

*/


/*
*/
db_begin();

$res = db_query("SELECT user_name FROM users WHERE status='A';");
if (!$res) {
	echo "Error!\n";
}

system("[ ! -d $upload_path/users ] && mkdir $upload_path/users");
system("chown www-data.www-data -R $upload_path/users");

while ( $row = db_fetch_array($res) ) {
	echo "Name:".$row["user_name"]." \n";

	if ($first_letter)
	   system ("[ ! -d $upload_path/users/".$row["user_name"][0]."/".$row["user_name"]." ] && mkdir -p $upload_path/users/".$row["user_name"][0]."/".$row["user_name"]);
	else
	   system ("[ ! -d $upload_path/users/".$row["user_name"]." ] && mkdir -p $upload_path/users/".$row["user_name"]);
}

system("chown www-data.www-data -R $upload_path/users");
system("cd $upload_path/users ; find -type d -exec chmod 700 {} \;");
system("cd $upload_path/users ; find -type f -exec chmod 600 {} \;");

db_commit();

?>
