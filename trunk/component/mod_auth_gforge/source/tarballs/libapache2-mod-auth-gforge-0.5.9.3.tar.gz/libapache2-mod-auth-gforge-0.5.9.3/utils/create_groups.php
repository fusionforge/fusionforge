#! /usr/bin/php -f
<?php
/**
 * create_groups.php 
 *
 * Francisco Gimeno <kikov@fco-gimeno.com>
 *
 * @version   $Id
 */

require ('squal_pre.php');

$first_letter = false;

/*

	This script create the gforge/upload directory for users

*/

if ($argc < 2 ) {
	echo "Usage ".$argv[0]." <path> <-f>\n";
	echo "-f  First Letter activated... do groups/m/myprojec\n";
	exit (0);
}
if ( $argv[2] ='-f' )
   $first_letter = true;
$upload_path = $argv[1];
echo "Creating Groups at ". $upload_path."\n";

db_begin();

$res = db_query("SELECT unix_group_name FROM groups;");
if (!$res) {
	echo "Error!\n";
}

system("[ ! -d ".$upload_path."/groups ] && mkdir $upload_path/groups"); 
system("chown www-data.www-data -R $upload_path/users");


while ( $row = db_fetch_array($res) ) {
	echo "Name:".$row["unix_group_name"]." \n";
	if ($first_letter)
		system ("[ ! -d $upload_path/groups/".$row["unix_group_name"][0]."/".$row["unix_group_name"]." ] && mkdir -p $upload_path/groups/".$row["unix_group_name"][0]."/".$row["unix_group_name"]);
	else
		system ("[ ! -d $upload_path/groups/".$row["unix_group_name"]." ] && mkdir $upload_path/groups/".$row["unix_group_name"]);
	
}

system("chown www-data.www-data -R $upload_path/groups");
system("cd $upload_path/groups ; find -type d -exec chmod 700 {} \;");
system("cd $upload_path/groups ; find -type f -exec chmod 600 {} \;");

db_commit();

?>
