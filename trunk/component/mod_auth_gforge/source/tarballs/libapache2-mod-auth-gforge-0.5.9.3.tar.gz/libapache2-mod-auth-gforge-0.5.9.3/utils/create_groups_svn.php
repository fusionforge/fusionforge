#! /usr/bin/php -f
<?php
/**
 * create_groups.php 
 *
 * Francisco Gimeno <kikov@fco-gimeno.com>
 *
 * @version   $Id
 */

require ('squal_pre.php');

$first_letter = false;

/*

	This script create the gforge/upload directory for users

*/

if ($argc < 2 ) {
	echo "Usage ".$argv[0]." <path> <-f>\n";
	echo "-f  First Letter activated... do groups/m/myprojec\n";
	exit (0);
}
if ( $argv[2] =='-f' )
   $first_letter = true;
else
   $first_letter = false;

$upload_path = $argv[1];
if ($first_letter == true )
     echo "First_Letter Active!:". $first_letter."\n";
else
     echo "First_Letter Deactive!:" .$first_letter."\n";

echo "Creating Groups at ". $upload_path."\n";

db_begin();

$res = db_query("SELECT unix_group_name FROM groups;");
if (!$res) {
	echo "Error!\n";
}

system("[ ! -d ".$upload_path."/groups ] && mkdir -p $upload_path/groups"); 
system("chown www-data.www-data -R $upload_path/groups");


while ( $row = db_fetch_array($res) ) {
	echo "Name:".$row["unix_group_name"]." \n";
	if ($first_letter==true) {
		system ("[ ! -d $upload_path/groups/".$row["unix_group_name"][0]." ] && mkdir -p $upload_path/groups/".$row["unix_group_name"][0]);
		system ("[ ! -d $upload_path/groups/".$row["unix_group_name"][0]."/".$row["unix_group_name"]." ] && svnadmin create $upload_path/groups/".$row["unix_group_name"][0]."/".$row["unix_group_name"]);
	}
	else
		system ("[ ! -d $upload_path/groups/".$row["unix_group_name"]." ] && svnadmin create $upload_path/groups/".$row["unix_group_name"]);
	
}

system("chown www-data.www-data -R $upload_path/groups");
system("cd $upload_path/groups ; find -type d -exec chmod 700 {} \;");
system("cd $upload_path/groups ; find -type f -exec chmod 600 {} \;");

db_commit();

?>
