/*
 * utils.c
 *
 * Apache module for Gforge
 * This module provides authentication and authorization
 * in a Location supporting projects path
 *
 * @author    Francisco Gimeno <kikov @ fco-gimeno.com>
 * @date      2004-03-01
 * @see
 *
 *
 *
 */

/*
 *  Util Functions
 *
 *  See descriptions in utils.h
 */

#include "../lconfig.h"

#include "debug.h"
#include "types.h"
#include "database.h"
#include "apacheconfig.h"

#include "httpd.h"
#include "apr_uri.h"
#include "apr_strings.h"
#include <libpq-fe.h>
#include <string.h>


int
gforge_access_method (int method_number)
{
    int authz_type = AUTHZ_WRITE;
    DBG ("[mod_auth_gforge.c] gforge_access_method: method_number %d",
	 method_number);
    switch (method_number)
    {
	/* All methods requiring read access to r->uri */
    case M_OPTIONS:
    case M_GET:
    case M_COPY:
    case M_PROPFIND:
    case M_REPORT: /* Supported by Apache 1.3? */
	authz_type = AUTHZ_READ;
	break;

	/* All methods requiring write access to r->uri */
    case M_MOVE:
    case M_MKCOL:
    case M_DELETE:
    case M_PUT:
    case M_PROPPATCH:
/*    case M_CHECKOUT:
      case M_MERGE:
      case M_MKACTIVITY: *//* Supported by Apache 1.3?
 */
	authz_type = AUTHZ_WRITE;
	break;
    default:
	/* Require most strict access for unknown methods */
	authz_type = AUTHZ_WRITE;
	break;
    }
    return authz_type;
}

int
is_users_dir (config_auth_gforge_state * sec, char *path)
{
/* We're supposing that strlen(path) > strlen(sec->gforgeUsersRoot ) */
    if (strncmp (sec->gforgeUsersRoot, path, strlen (sec->gforgeUsersRoot)) ==
	0)
    {
	if (path[strlen (sec->gforgeUsersRoot)] == '/')
	{
	    DBG ("[mod_auth_gforge.c]   Path is a USER_DIR");
	    return TRUE;
	}
    }
    else
    {
	DBG ("[mod_auth_gforge.c]   Path is NOT a USER_DIR");

    }
    return FALSE;
}

int
is_groups_dir (config_auth_gforge_state * sec, char *path)
{
/* We're supposing that strlen(path) > strlen(sec->gforgeGroupsRoot ) */
    if (strncmp (sec->gforgeGroupsRoot, path, strlen (sec->gforgeGroupsRoot)) ==
	0)
    {
	if (path[strlen (sec->gforgeGroupsRoot)] == '/')
	{
	    DBG ("[mod_auth_gforge.c]   Path is a GROUP_DIR");
	    return TRUE;
	}
    }
    else
    {
	DBG ("[mod_auth_gforge.c]   Path is NOT a GROUP_DIR");

    }
    return FALSE;
}

/* Check for path1=path2 except the slash */
int
same_path (char *path1, char *path2)
{
    DBG ("[mod_auth_gforge.c] - same_path ( %s, %s )", path1, path2);

    if (strncmp (path1, path2, strlen (path1) < strlen (path2) ?
		 strlen (path1) : strlen (path2)) == 0 &&
	abs ((strlen (path1) - strlen (path2))) <= 1 && 
	(  path1[ strlen( path1 ) -1 ] == '/' || path2[ strlen( path2 ) -1 ] =='/' ) )
    {
	DBG ("[mod_auth_gforge.c] Paths are the same");
	return TRUE;
    }
    else
    {
	DBG ("[mod_auth_gforge.c] Paths are differents");
	return FALSE;
    }

}

int
is_root_dir (config_auth_gforge_state * sec, char *root, char *path)
{
    DBG ("[mod_auth_gforge.c] - is_root_dir(%s,%s) ", root, path);
    if (strncmp( path,root, strlen( path ) ) == 0 ) {
	DBG( "[mod_auth_gforge.c] is_root_dir : we're just before a root dir " );
	return TRUE;
    }
    if (same_path (root, path) == TRUE)
    {
	DBG ("[mod_auth_gforge.c] is_root_dir(%s,%s) - TRUE", root, path);
	return TRUE;		/* groups or groups/ */
    }
    /* Check if we're looking for a file in a root dir, that's enabled by default */
    if (strncmp(root, path, strlen( root ) ) ==0 ) {
	DBG( "[mod_auth_gforge.c] is_root_dir : checking if this is a file in a rootdir" );
	if ( strstr( path + strlen( root ) + 2, "/" ) == NULL) {
		DBG( "[mod_auth_gforge.c] is_root_dir: this is a file in a root dir. No other / found" );
		return TRUE;
	}
    }
    if (sec->first_letter == TRUE)
    {	/* root = /groups, path= /groups/t/ */
	DBG ("[mod_auth_gforge.c] testing if we're in the first letter");
	if (strncmp (root, path, strlen (root)) == 0)
	{ // Begining match
	    DBG ("[mod_auth_gforge.c] we're in root");
	    if (strlen (path) < strlen (root) + 2 ) {
		DBG("[mod_auth_gforge.c] we should be listing letters" );
		return TRUE; /* groups/ */
	    }
	    if (strlen (path) == strlen (root) + 2)
	    {
		DBG ("[mod_auth_gforge.c] We have 2 letters more");
		if (path[strlen (root)] == '/')
		    return TRUE;	/* groups/m */
	    }
	    if (strlen (path) == strlen (root) + 3)
	    {
		DBG ("[mod_auth_gforge.c] We have 3 letters more");
		if (path[strlen (root)] == '/' &&
		    path[strlen (root) + 2] == '/')
		    return TRUE;	/* groups/m/ */
	    }
	}

    }
  DBG( "[mod_auth_gforge.c] This is not a root dir" );
    return FALSE;
}

char *
remove_prefix (config_auth_gforge_state * sec, char *root, char *path)
{
    DBG ("[mod_auth_gforge.c] - remove_prefix ( root=%s, path=%s )", root,
	 path);
    /* We remove suffix "/" from root: root = /groups */
    /* path = /groups/t/test3 */
    if (root[strlen (root) - 1] == '/')
	root[strlen (root) - 1] = 0;

    if (strncmp (root, path, strlen (root)) == 0) /* Check root is prefix of path */
    {
	DBG ("[mod_auth_gforge.c] Prefix match"); /* Path begins by /groups */
	if (sec->first_letter == TRUE && (strlen (path) > strlen (root) + 3))
	{  /* For firts_letter: /groups/t/test3 */
	    DBG ("[mod_auth_gforge.c] First Letter check");
	    if (path[strlen (root) + 1 ] == '/' && path[strlen (root) + 3] == '/') /* TODO: Check boundaries of path */
		if (path[strlen (root) + 2] ==	/* First letter is equal */
		    path[strlen (root) + 4])
		{
		    DBG ("[mod_auth_gforge.c] PREFIX: %s",
			 path + strlen (root) + 4);
		    return path + strlen (root) + 4;
		}

	}

	if (sec->first_letter == FALSE && (strlen (path) > strlen (root) + 1))
	{
	    DBG ("[mod_auth_gforge.c] Prefix: %s", path + strlen (root) + 1);
	    DBG ("[mod_auth_gforge.c]   remove_prefix return %s",
		 path + strlen (root) + 1);
	    return path + strlen (root) + 1;
	}

    }

    return NULL;
}

int
get_kind_from_uri (config_auth_gforge_state * sec, request_rec * r, char *uri)
{
//    char *root_dir = NULL; TODO: See if it could be removed

    apr_uri_t *uptr = (apr_uri_t *) apr_pcalloc (r->pool, sizeof (apr_uri_t));

    if (uptr == NULL)
	return -1;

    DBG ("[mod_auth_gforge.c] - get_kind_from_uri init ( uri =%s )", uri);
    apr_uri_parse (r->pool, uri, uptr);

    DBG ("[mod_auth_gforge.c]     Path To Check:%s", uptr->path);

    /* Test if we're */
    /*      in groups/ or users/ */
    if (sec->gforgeGroupsRoot)
	if (is_root_dir (sec, sec->gforgeGroupsRoot, uptr->path) == TRUE)
	    return ROOT_DIR;

    if (sec->gforgeUsersRoot)
	if (is_root_dir (sec, sec->gforgeUsersRoot, uptr->path) == TRUE)
	    return ROOT_DIR;


    if (sec->gforgeUsersRoot)
	if (is_users_dir (sec, uptr->path))
	    return USERS_DIR;

    if (sec->gforgeGroupsRoot)
	if (is_groups_dir (sec, uptr->path))
	    return GROUPS_DIR;

    if ((sec->gforgeGroupsRoot &&
	 strncmp (sec->gforgeGroupsRoot, uptr->path,
		  strlen (uptr->path)) == 0)
	|| (sec->gforgeUsersRoot &&
	    strncmp (sec->gforgeUsersRoot, uptr->path,
		     strlen (uptr->path)) == 0))
    {
	/* A path toward gforge[Groups|Users]Root */
	return ROOT_DIR;
    }

    DBG ("[mod_auth_gforge.c] Path %s is UNKNOWN_DIR", uptr->path);
    return UNKNOWN_DIR;
}


char *
extract_group_from_uri (config_auth_gforge_state * sec, request_rec * r,
			char *uri)
{
    char *safe_group = NULL;
    char sql[MAX_STRING_LEN];
    char *s;
    char *tokens;

    apr_uri_t *uptr = (apr_uri_t *) apr_pcalloc (r->pool, sizeof (apr_uri_t));

    safe_group = (char *) apr_pcalloc (r->pool, 1 + 2 * strlen (uri));

    s = tokens = NULL;

    DBG ("[mod_auth_gforge.c] - extract_group_from_uri (uri =%s)  ", uri);

    apr_uri_parse (r->pool, uri, uptr);
    DBG ("[mod_auth_gforge.c]  GroupsRoot:%s\tUri: %s",
	 sec->gforgeGroupsRoot, uptr->path);

    tokens = remove_prefix (sec, sec->gforgeGroupsRoot, uptr->path);
    DBG ("[mod_auth_gforge.c] After remove prefix: %s", tokens);
    if (tokens != NULL)
    {
	tokens = strtok (tokens, "/");

	pg_check_string (safe_group, tokens, strlen (tokens));
	if (safe_group != NULL)
	{
	    snprintf (sql, MAX_STRING_LEN,
		      "select %s from %s where "
		      "unix_group_name='%s'",
		      sec->auth_pg_grp_field,
		      sec->auth_pg_grp_table, safe_group);
	    DBG ("[mod_auth_gforge.c]  Group Query %s", sql);
	    s = do_pg_query (r, sql, sec);
	}
    }
    else
    {
	DBG ("[mod_auth_gforge.c]  Sorry, incorrect path to Group. Check First_Letter in "
			"  config File");
	return NULL;
    }


    if (s == NULL)
	DBG ("[mod_auth_gforge.c]  Sorry, group not found");
    else
	DBG ("[mod_auth_gforge.c]  Group found %s", s);

    return s;
}

const char *
extract_user_from_uri (config_auth_gforge_state * sec, request_rec * r,
		       char *uri)
{
    char *safe_user = NULL;
    char sql[MAX_STRING_LEN];
    char *s;
    char *tokens;

    apr_uri_t *uptr = (apr_uri_t *) apr_pcalloc (r->pool, sizeof (apr_uri_t));

    safe_user = (char *) apr_pcalloc (r->pool, 1 + 2 * strlen (uri));

    s = tokens = NULL;

    DBG ("[mod_auth_gforge.c]  extract_user_from_uri init");
    DBG ("[mod_auth_gforge.c]  UsersRoot:%s", sec->gforgeUsersRoot);
    apr_uri_parse (r->pool, uri, uptr);
    DBG ("[mod_auth_gforge.c]  extracted %s, %s", uptr->path,
	 sec->gforgeUsersRoot);

    tokens = remove_prefix (sec, sec->gforgeUsersRoot, uptr->path);
    tokens = strtok (tokens, "/");

    if (tokens != NULL)
    {
	DBG ("[mod_auth_gforge.c]  tokenizing:%s", tokens);
	pg_check_string (safe_user, tokens, strlen (tokens));
	if (safe_user != NULL)
	{
	    snprintf (sql, MAX_STRING_LEN, "SELECT %s FROM %s WHERE "
		      "%s='%s' AND status='A'",
		      sec->auth_pg_uname_field,
		      sec->auth_pg_pwd_table,
		      sec->auth_pg_uname_field, safe_user);
	    DBG ("[mod_auth_gforge.c]  User Query %s", sql);
	    s = do_pg_query (r, sql, sec);
	    DBG ("[mod_auth_gforge.c]  Query done");
	}
    }
    else
    {
	return NULL;
    }

    DBG ("[mod_auth_gforge.c]  tokenized: %s", safe_user);

    if (s == NULL)
	DBG ("[mod_auth_gforge.c]  Sorry, User not found");
    else
	DBG ("[mod_auth_gforge.c]  User %s found ", s);

    return s;
}

int
is_private_dir (config_auth_gforge_state * sec, request_rec * r, char *uri)
{
    char *safe_user = NULL;
    char sql[MAX_STRING_LEN];
    char *s, *tokens, *local_path;


    apr_uri_t *uptr = (apr_uri_t *) apr_pcalloc (r->pool, sizeof (apr_uri_t));

    safe_user = (char *) apr_pcalloc (r->pool, 1 + 2 * strlen (uri));

    s = tokens = NULL;

    DBG ("[mod_auth_gforge.c]  is_private_dir init");
    DBG ("[mod_auth_gforge.c]  UsersRoot:%s", sec->gforgeUsersRoot);
    apr_uri_parse (r->pool, uri, uptr);
    local_path = (char *) apr_pstrdup (r->pool, uptr->path);
    DBG ("[mod_auth_gforge.c]  extracted %s, %s", uptr->path,
	 sec->gforgeUsersRoot);

    if (strncmp (uptr->path,
		 sec->gforgeUsersRoot, strlen (sec->gforgeUsersRoot)) == 0)
    {
	tokens = uptr->path + strlen (sec->gforgeUsersRoot);
	DBG ("[mod_auth_gforge.c] Not Bizarre UsersGroup!%s", uptr->path);
    }
    else
    {
	DBG ("[mod_auth_gforge.c] Bizarre UsersGroup!%s", uptr->path);
	return FALSE;
    }

    tokens = strtok (tokens, "/");

    if (tokens != NULL)
    {
	DBG ("[mod_auth_gforge.c] 1st Token:%s", tokens);
	pg_check_string (safe_user, tokens, strlen (tokens));
	if (safe_user != NULL)
	{
	    snprintf (sql, MAX_STRING_LEN, "SELECT %s FROM %s WHERE "
		      "user_name='%s' AND status='A'",
		      sec->auth_pg_uname_field, sec->auth_pg_pwd_table,
		      safe_user);
	    DBG ("[mod_auth_gforge.c]  Owner Query %s", sql);
	    s = do_pg_query (r, sql, sec);
	    DBG ("[mod_auth_gforge.c]  Query done");
	}
    }
    else
    {
	return FALSE;
    }

    DBG ("[mod_auth_gforge.c]  tokenized: %s", safe_user);

    if (s == NULL)
	DBG ("[mod_auth_gforge.c]  Sorry, user not found");
    else
	DBG ("[mod_auth_gforge.c]  Owner found %s", s);

    tokens = strtok (NULL, "/");
    if (tokens != NULL)
    {
	if (strcmp (tokens, "private") == 0)
	    return TRUE;
    }

    return FALSE;
}

int
group_contains_user (config_auth_gforge_state * sec, const char
		     *group, const char *user, request_rec * r)
{
    char sql[MAX_STRING_LEN];
    char *s;
    char safe_user[1 + 2 * strlen (user)];
    char safe_group[1 + 2 * strlen (group)];

    pg_check_string (safe_user, user, strlen (user));
    pg_check_string (safe_group, group, strlen (group));

    snprintf (sql, MAX_STRING_LEN, "SELECT %s.unix_group_name FROM %s,"
	      "%s,user_group WHERE %s.user_id=user_group.user_id AND "
	      "user_group.group_id = %s.group_id AND %s.user_name='%s' "
	      "and %s.unix_group_name='%s'", sec->auth_pg_grp_table,
	      	sec->auth_pg_grp_table, sec->auth_pg_pwd_table,
	      	sec->auth_pg_pwd_table, sec->auth_pg_grp_table,
		sec->auth_pg_pwd_table, safe_user, sec->auth_pg_grp_table,
		safe_group);

    s = do_pg_query (r, sql, sec);
    DBG ("[mod_auth_gforge.c] Query Result: %s, Query: %s", s, sql);
    if (s != NULL)
	return TRUE;
    else
	return FALSE;

}


int
group_active (config_auth_gforge_state * sec, const char
	      *group, request_rec * r)
{
    char sql[MAX_STRING_LEN];
    char *s, *val;
    char safe_group[1 + 2 * strlen (group)];

    pg_check_string (safe_group, group, strlen (group));

    if (sec->auth_pg_cache_passwords
	&& (!apr_is_empty_table (sec->cache_group_active_table)))
    {
	DBG ("[mod_auth_gforge.c] Group_Active Looking in Cache Table..");
	val =
	    (char *) apr_table_get (sec->cache_group_active_table, safe_group);

	if (val)
	{
	    DBG ("[mod_auth_gforge.c] Group_Active found in Cache ");
	    if (*val == 'A')
		return TRUE;
	    else
		return FALSE;
	}
    }

    snprintf (sql, MAX_STRING_LEN, "SELECT status FROM %s "
	      "WHERE unix_group_name='%s'", sec->auth_pg_grp_table,
	      safe_group);

    s = do_pg_query (r, sql, sec);
    DBG ("[mod_auth_gforge.c] Query Result: %s, Query:" "%s", s, sql);

    if (s && *s == 'A')
    {
	/* store password in the cache : ACTIVE */
	if (sec->auth_pg_cache_passwords && sec->cache_group_active_table)
	{
	    if ((apr_table_elts (sec->cache_group_active_table))->nelts >=
		MAX_TABLE_LEN)
		apr_table_clear (sec->cache_group_active_table);
	    apr_table_set (sec->cache_group_active_table, safe_group, "A");
	}
	return TRUE;
    }
    else
    {
	/* store password in the cache : NOT ACTIVE */
	if (sec->auth_pg_cache_passwords && sec->cache_group_active_table)
	{
	    if ((apr_table_elts (sec->cache_group_active_table))->nelts >=
		MAX_TABLE_LEN)
		apr_table_clear (sec->cache_group_active_table);
	    apr_table_set (sec->cache_group_active_table, safe_group, " ");
	}
	return FALSE;
    }
    return FALSE;
}

int
user_active (config_auth_gforge_state * sec, const char *user, request_rec * r)
{
    char sql[MAX_STRING_LEN];
    char *s, *val;
    char safe_user[1 + 2 * strlen (user)];

    pg_check_string (safe_user, user, strlen (user));

    if (sec->auth_pg_cache_passwords
	&& (!apr_is_empty_table (sec->cache_user_active_table)))
    {
	DBG ("[mod_auth_gforge.c] User_Active Looking in Cache Table..");
	val = (char *) apr_table_get (sec->cache_user_active_table, safe_user);

	if (val)
	{
	    DBG ("[mod_auth_gforge.c] User_Active found in Cache ");
	    if (*val == 'A')
		return TRUE;
	    else
		return FALSE;
	}

    }
    snprintf (sql, MAX_STRING_LEN, "SELECT status FROM %s "
	      "WHERE user_name='%s'", sec->auth_pg_pwd_table, safe_user);

    s = do_pg_query (r, sql, sec);
    DBG ("[mod_auth_gforge.c] Query Result: %s, Query: %s", s, sql);
    if (s && *s == 'A')
    {
	/* store password in the cache : ACTIVE */
	if (sec->auth_pg_cache_passwords && sec->cache_user_active_table)
	{
	    if ((apr_table_elts (sec->cache_user_active_table))->nelts >=
		MAX_TABLE_LEN)
		apr_table_clear (sec->cache_user_active_table);
	    apr_table_set (sec->cache_user_active_table, safe_user, "A");
	}
	return TRUE;
    }
    else
    {
	/* store password in the cache : NOT ACTIVE */
	if (sec->auth_pg_cache_passwords && sec->cache_user_active_table)
	{
	    if ((apr_table_elts (sec->cache_user_active_table))->nelts >=
		MAX_TABLE_LEN)
		apr_table_clear (sec->cache_user_active_table);
	    apr_table_set (sec->cache_user_active_table, safe_user, " ");
	}
	return FALSE;
    }
}

int
is_group_public (config_auth_gforge_state * sec, const char
		 *group, request_rec * r)
{
    char sql[MAX_STRING_LEN];
    char *s, *val;
    char safe_group[1 + 2 * strlen (group)];

    pg_check_string (safe_group, group, strlen (group));
    if (sec->auth_pg_cache_passwords
	&& (!apr_is_empty_table (sec->cache_group_public_table)))
    {
	DBG ("[mod_auth_gforge.c] Group_Public Looking in Cache Table..");
	val =
	    (char *) apr_table_get (sec->cache_group_public_table, safe_group);

	if (val)
	{
	    DBG ("[mod_auth_gforge.c] Group_Public found in Cache ");
	    if (*val == '1')
		return TRUE;
	    else
		return FALSE;
	}

    }
    snprintf (sql, MAX_STRING_LEN, "SELECT is_public FROM %s "
	      "WHERE unix_group_name='%s'", sec->auth_pg_grp_table,
	      safe_group);

    s = do_pg_query (r, sql, sec);
    DBG ("[mod_auth_gforge.c] Query Result: %s, Query: %s", s, sql);

    if (s && *s == '1')
    {
	/* store password in the cache : ACTIVE */
	if (sec->auth_pg_cache_passwords && sec->cache_group_public_table)
	{
	    if ((apr_table_elts (sec->cache_group_public_table))->nelts >=
		MAX_TABLE_LEN)
		apr_table_clear (sec->cache_group_public_table);
	    apr_table_set (sec->cache_group_public_table, safe_group, "1");
	}
	return TRUE;
    }
    else
    {
	/* store password in the cache : NOT ACTIVE */
	if (sec->auth_pg_cache_passwords && sec->cache_group_public_table)
	{
	    if ((apr_table_elts (sec->cache_group_public_table))->nelts >=
		MAX_TABLE_LEN)
		apr_table_clear (sec->cache_group_public_table);
	    apr_table_set (sec->cache_group_public_table, safe_group, "0");
	}
	return FALSE;
    }
}

int
is_user_siteadmin (config_auth_gforge_state * sec, const char
		   *user, request_rec * r)
{
    char sql[MAX_STRING_LEN];
    char *s, *val;
    char safe_user[1 + 2 * strlen (user)];

    pg_check_string (safe_user, user, strlen (user));

    if (sec->auth_pg_cache_passwords
	&& (!apr_is_empty_table (sec->cache_siteadmin_table)))
    {
	DBG ("[mod_auth_gforge.c] SiteAdmin: Looking in Cache Table..");
	val = (char *) apr_table_get (sec->cache_siteadmin_table, safe_user);

	if (val)
	{
	    DBG ("[mod_auth_gforge.c] SiteAdmin found in Cache ");
	    if (*val == '1')
		return TRUE;
	    else
		return FALSE;
	}

    }

    snprintf (sql, MAX_STRING_LEN, "SELECT %s.user_name FROM %s,"
	      "user_group,%s WHERE %s.user_id=user_group.user_id AND %s.group_id=1 "
	      "and user_name='%s' AND %s.group_id=user_group.group_id AND %s.status='A'"
	      "AND user_group.admin_flags='A';",
	      sec->auth_pg_pwd_table, sec->auth_pg_pwd_table, sec->auth_pg_grp_table,
	      sec->auth_pg_pwd_table, sec->auth_pg_grp_table, safe_user, sec->auth_pg_grp_table,
	      sec->auth_pg_pwd_table );
    s = do_pg_query (r, sql, sec);
    DBG ("[mod_auth_gforge.c] Query Result: %s, Query: %s", s, sql);
    if (s != NULL)
    {
	/* store admin in the cache : ACTIVE */
	if (sec->auth_pg_cache_passwords && sec->cache_siteadmin_table)
	{
	    if ((apr_table_elts (sec->cache_siteadmin_table))->nelts >=
		MAX_TABLE_LEN)
		apr_table_clear (sec->cache_siteadmin_table);
	    apr_table_set (sec->cache_siteadmin_table, safe_user, "1");
	}
	return TRUE;
    }
    else
    {
	/* store admin in table in the cache : NOT ACTIVE */
	if (sec->auth_pg_cache_passwords && sec->cache_siteadmin_table)
	{
	    if ((apr_table_elts (sec->cache_siteadmin_table))->nelts >=
		MAX_TABLE_LEN)
		apr_table_clear (sec->cache_siteadmin_table);
	    apr_table_set (sec->cache_siteadmin_table, safe_user, "0");
	}
	return FALSE;
    }

}

int
user_is_groupadmin (config_auth_gforge_state * sec, const char
		    *user, const char *group, request_rec * r)
{
    char sql[MAX_STRING_LEN];
    char *s;
    char safe_user[1 + 2 * strlen (user)];
    char safe_group[1 + 2 * strlen (group)];

    pg_check_string (safe_user, user, strlen (user));
    pg_check_string (safe_group, group, strlen (group));

    snprintf (sql, MAX_STRING_LEN, "SELECT %s.user_name FROM %s,"
	      "user_group,%s WHERE users.user_id=user_group.user_id and "
	      "%s.user_name='%s' AND %s.unix_group_name='%s' "
	      "AND user_group.admin_flags='A' and user_group.group_id="
	      "%s.group_id", 
	      sec->auth_pg_pwd_table,sec->auth_pg_pwd_table,sec->auth_pg_grp_table,
	      sec->auth_pg_pwd_table, safe_user, sec->auth_pg_grp_table, safe_group,
	      sec->auth_pg_grp_table);

    s = do_pg_query (r, sql, sec);
    DBG ("[mod_auth_gforge.c] Query Result: %s, Query: %s", s, sql);
    if (s != NULL)
	return TRUE;
    else
	return FALSE;
}

int
user_is_member (config_auth_gforge_state * sec, const char
		    *user, const char *group, request_rec * r)
{
    char sql[MAX_STRING_LEN];
    char *s;
    char safe_user[1 + 2 * strlen (user)];
    char safe_group[1 + 2 * strlen (group)];

    pg_check_string (safe_user, user, strlen (user));
    pg_check_string (safe_group, group, strlen (group));

    snprintf (sql, MAX_STRING_LEN, "SELECT %s.user_name FROM %s,"
	      "user_group,%s WHERE %s.user_id=user_group.user_id and "
	      "%s.user_name='%s' AND %s.unix_group_name='%s' "
	      " and user_group.group_id="
	      "groups.group_id", sec->auth_pg_pwd_table,sec->auth_pg_pwd_table,
	      sec->auth_pg_grp_table, sec->auth_pg_pwd_table, sec->auth_pg_pwd_table,
	      safe_user, sec->auth_pg_grp_table, safe_group);

    s = do_pg_query (r, sql, sec);
    DBG ("[mod_auth_gforge.c] Query Result: %s, Query: %s", s, sql);
    if (s != NULL)
	return TRUE;
    else
	return FALSE;
}

char *
string_substitute (apr_pool_t * p, char *orig, char *a, char *b)
{
    int i;
    char *result, *workstr;

    result = workstr =
	(char *) apr_pcalloc (p, sizeof (char) * strlen (orig) * strlen (b));

    do
    {
	if (strstr (orig, a) == orig)
	{
	    for (i = 0; i < strlen (b); i++)
		*workstr++ = b[i];
	    orig += strlen (a) - 1;
	}
	else
	    *workstr++ = *orig;
    }
    while (*++orig);

    return result;
}


char *
get_clause (apr_pool_t * pool,
	    char *clause, char *uri, int access_type, char *real_user,
	    char *real_group)
{
    char *result;
    DBG ("[mod_auth_gforge.c]  get_clause: orig %s", clause);
    result = clause;


    result = string_substitute (pool, result, "$G", real_group);


    result = string_substitute (pool, result, "$U", real_user);

    if (access_type == AUTHZ_READ)
	result = string_substitute (pool, result, "$A", "READ");
    else
	result = string_substitute (pool, result, "$A", "WRITE");

    if (strstr (result, "$G") != NULL && strstr (result, "$u") != NULL)
    {
	DBG ("[mod_auth_gforge.c]  get_clause: some parameters are "
	     "yet unsubstituted:%s", result);
	return NULL;
    }

    return result;
}
