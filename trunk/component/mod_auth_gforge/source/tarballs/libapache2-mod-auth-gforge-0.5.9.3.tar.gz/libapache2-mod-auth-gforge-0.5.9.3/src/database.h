/**
 * database.c
 *
 * Apache module for Gforge
 * This module provides authentication and authorization
 * in a Location supporting projects path
 *
 * @author    Francisco Gimeno <kikov @ fco-gimeno.com>
 * @date      2004-02-19
 * @see
 *
 *
 *
 */

/*
 *  Database Support Functions
 *
 *
 */
#ifndef _DATABASE_H_
#define _DATABASE_H_

#include <libpq-fe.h>
#include <string.h>

int
pg_log_auth_user (request_rec * r, config_auth_gforge_state * sec, char *user,
		  char *sent_pw);
char *auth_pg_md5 (char *pw);
size_t pg_check_string (char *to, const char *from, size_t length);
char *do_pg_query (request_rec * r, char *query,
		   config_auth_gforge_state * sec);

#endif
