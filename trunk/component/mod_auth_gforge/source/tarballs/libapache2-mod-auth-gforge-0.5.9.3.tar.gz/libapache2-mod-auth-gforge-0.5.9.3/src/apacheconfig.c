/**
 * apacheconfig.c
 *
 * Apache module for Gforge
 * This module provides authentication and authorization
 * in a Location supporting projects path
 *
 * @author    Francisco Gimeno <kikov @ fco-gimeno.com>
 * @date      2004-02-19
 * @see
 *
 *
 *
 */

/*
 *  Apache Config Support Functions
 *
 *
 */
#include "types.h"
#include "debug.h"

#include "apr_strings.h"
#include <httpd.h>
#include <http_config.h>
#include <http_request.h>
#include <http_protocol.h>

extern apr_pool_t *auth_gforge_pool;

void *
create_dir_config (apr_pool_t * p, char *d)
{
    config_auth_gforge_state *new_state;

    new_state =
	(config_auth_gforge_state *) apr_pcalloc (p,
						  sizeof
						  (config_auth_gforge_state));
    if (new_state == NULL)
	return NULL;

    if (auth_gforge_pool == NULL)
	apr_pool_create_ex (&auth_gforge_pool, p, NULL, NULL);
    if (auth_gforge_pool == NULL)
	return NULL;

    /* Safe Defaults Settings */
    new_state->gforgeSysPath = NULL;
    new_state->gforgeGroupsRoot = NULL;
    new_state->gforgeUsersRoot = NULL;
    new_state->gforgeAuthClause = NULL;
    new_state->gforgeReadClause = NULL;
    new_state->gforgeWriteClause = NULL;
    new_state->gforgeAnonClause = NULL;

    new_state->auth_pg_host = NULL;
    new_state->auth_pg_database = "gforge";
    new_state->auth_pg_port = NULL;
    new_state->auth_pg_options = NULL;
    new_state->auth_pg_user = "gforge";
    new_state->auth_pg_pwd = NULL;
    new_state->auth_pg_pwd_table = "users";
    new_state->auth_pg_grp_table = "groups";
    new_state->auth_pg_uname_field = "user_name";
    new_state->auth_pg_pwd_field = "unix_pw";
    new_state->auth_pg_grp_field = "unix_group_name";
    new_state->auth_pg_pwd_whereclause = NULL;
    new_state->auth_pg_grp_whereclause = NULL;

    new_state->auth_pg_nopasswd = 0;
    new_state->auth_pg_authoritative = 1;
    new_state->auth_pg_lowercaseuid = 0;
    new_state->auth_pg_uppercaseuid = 0;
    new_state->auth_pg_pwdignorecase = 0;
    new_state->auth_pg_encrypted = 1;
    new_state->auth_pg_hash_type = AUTH_PG_HASH_TYPE_CRYPT;
    new_state->auth_pg_cache_passwords = 0;
    new_state->auth_default_access_type = AUTH_DEFAULT_ACCESS_TYPE_DECLINE;
    new_state->auth_default_author_type = AUTH_DEFAULT_ACCESS_TYPE_FORBID;

    new_state->auth_pg_log_table = NULL;
    new_state->auth_pg_log_addrs_field = NULL;
    new_state->auth_pg_log_uname_field = NULL;
    new_state->auth_pg_log_pwd_field = NULL;
    new_state->auth_pg_log_date_field = NULL;
    new_state->auth_pg_log_uri_field = NULL;
    
    new_state->base_path = d;

    new_state->first_letter = 0;

    new_state->cache_pass_table =
	apr_table_make (auth_gforge_pool, MAX_TABLE_LEN);

    if (new_state->cache_pass_table == NULL)
	return NULL;

    new_state->cache_group_active_table =
	apr_table_make (auth_gforge_pool, MAX_TABLE_LEN);
    if (new_state->cache_group_active_table == NULL)
	return NULL;
    new_state->cache_group_public_table =
	apr_table_make (auth_gforge_pool, MAX_TABLE_LEN);
    if (new_state->cache_group_public_table == NULL)
	return NULL;
    new_state->cache_user_active_table =
	apr_table_make (auth_gforge_pool, MAX_TABLE_LEN);
    if (new_state->cache_user_active_table == NULL)
	return NULL;
    new_state->cache_siteadmin_table =
	apr_table_make (auth_gforge_pool, MAX_TABLE_LEN);
    if (new_state->cache_siteadmin_table == NULL)
	return NULL;

    DBG ("[mod_auth_gforge.c] create_dir_config() Dir: %s", d);

    return new_state;
}

/**
 * Apache Set Directives
 */


/**
 * Passwd with crypt() or MD5()
 */
static const char *
pg_set_hash_type (cmd_parms * cmd, void *config, const char *hash_type)
{
    config_auth_gforge_state *mConfig = config;

    if (!strcasecmp (hash_type, "MD5"))
	mConfig->auth_pg_hash_type = AUTH_PG_HASH_TYPE_MD5;
    else if (!strcasecmp (hash_type, "CRYPT"))
	mConfig->auth_pg_hash_type = AUTH_PG_HASH_TYPE_CRYPT;
    else
	return (char *) apr_pstrcat (cmd->pool,
				     "Invalid hash type for Auth_PG_hash_type: ",
				     hash_type, NULL);
    return NULL;
}

static const char *
set_default_access_type (cmd_parms * cmd, void *config,
			 const char *default_access_type)
{
    config_auth_gforge_state *mConfig = config;

    if (!strcasecmp (default_access_type, "FORBID"))
	mConfig->auth_default_access_type = AUTH_DEFAULT_ACCESS_TYPE_FORBID;
    else if (!strcasecmp (default_access_type, "DECLINE"))
	mConfig->auth_default_access_type = AUTH_DEFAULT_ACCESS_TYPE_DECLINE;
    else
	return (char *) apr_pstrcat (cmd->pool,
				     "Invalid type for default_access_type: ",
				     default_access_type, NULL);
    return NULL;
}

static const char *
set_default_author_type (cmd_parms * cmd, void *config,
			 const char *default_author_type)
{
    config_auth_gforge_state *mConfig = config;

    if (!strcasecmp (default_author_type, "FORBID"))
	mConfig->auth_default_author_type = AUTH_DEFAULT_ACCESS_TYPE_FORBID;
    else if (!strcasecmp (default_author_type, "DECLINE"))
	mConfig->auth_default_author_type = AUTH_DEFAULT_ACCESS_TYPE_DECLINE;
    else
	return (char *) apr_pstrcat (cmd->pool,
				     "Invalid type for default_author_type: ",
				     default_author_type, NULL);
    return NULL;
}



static const char *
pg_set_lowercaseuid_flag (cmd_parms * cmd, void *config, int arg)
{
    config_auth_gforge_state *mConfig = config;

    mConfig->auth_pg_lowercaseuid = arg;
    mConfig->auth_pg_uppercaseuid = 0;
    return NULL;
}

static const char *
pg_set_uppercaseuid_flag (cmd_parms * cmd, void *config, int arg)
{
    config_auth_gforge_state *mConfig = config;

    mConfig->auth_pg_uppercaseuid = arg;
    mConfig->auth_pg_lowercaseuid = 0;
    return NULL;
}

/*
 * Default Config: TODO see if this is used
 */
void *
make_config_auth_gforge (apr_pool_t * p, server_rec * s)
{
    config_auth_gforge_state *cks = (config_auth_gforge_state *) apr_pcalloc (p,
									      sizeof
									      (config_auth_gforge_state));
    cks->gforgeSysPath = NULL;
    return (void *) cks;
}


command_rec config_auth_gforge_cmds[] = {
    AP_INIT_TAKE1 ("GforgeSysPath",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  gforgeSysPath),
		   OR_AUTHCFG,
		   "Path to the Root of the virtualhost (not used but required)"),

    AP_INIT_TAKE1 ("GforgeUsersRoot",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  gforgeUsersRoot),
		   OR_AUTHCFG,
		   "Path to the Root of the users directory"),

    AP_INIT_TAKE1 ("GforgeGroupsRoot",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  gforgeGroupsRoot),
		   OR_AUTHCFG,
		   "Path to the Root of the groups directory"),

    AP_INIT_TAKE1 ("GforgeAuthClause",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  gforgeAuthClause),
		   OR_AUTHCFG,
		   "Query that should return a non-NULL value to authorize an access"),

    AP_INIT_TAKE1 ("GforgeReadClause",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  gforgeReadClause),
		   OR_AUTHCFG,
		   "Query that should return a non-NULL value to authorize an read-access"
		   " based on flags: example, GforgeReadClause doc_flags>1"),

    AP_INIT_TAKE1 ("GforgeWriteClause",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  gforgeWriteClause),
		   OR_AUTHCFG,
		   "Query that should return a non-NULL value to authorize an write-access"
		   " based on flags: example, GforgeWriteClause doc_flags>2"),

    AP_INIT_TAKE1 ("GforgeAnonClause",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  gforgeAnonClause),
		   OR_AUTHCFG,
		   "Query that should return a non-NULL value to authorize an anonymous-access"
		   " based on flags: example, GforgeAnonClause group.anon_cvs>=0"),

    AP_INIT_TAKE1 ("Auth_PG_host",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_host),
		   OR_AUTHCFG,
		   "The host name of the postgreSQL server."),

    AP_INIT_TAKE1 ("Auth_PG_database",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_database),
		   OR_AUTHCFG,
		   "The name of the Database that contains authorization information. "),

    AP_INIT_TAKE1 ("Auth_PG_port",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_port),
		   OR_AUTHCFG,
		   "The port the postmaster is running on. "),

    AP_INIT_TAKE1 ("Auth_PG_options",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_options),
		   OR_AUTHCFG,
		   "An options string to be sent to the postgreSQL backed proccess."),

    AP_INIT_TAKE1 ("Auth_PG_user",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_user),
		   OR_AUTHCFG,
		   "User name connect as"),

    AP_INIT_TAKE1 ("Auth_PG_pwd",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_pwd),
		   OR_AUTHCFG,
		   "User database Password "),

    AP_INIT_TAKE1 ("Auth_PG_pwd_table",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_pwd_table),
		   OR_AUTHCFG,
		   "The name of the table containing username/password tuples."),

    AP_INIT_TAKE1 ("Auth_PG_grp_table",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_grp_table),
		   OR_AUTHCFG,
		   "The name of the table containing username/group tuples."),

    AP_INIT_TAKE1 ("Auth_PG_pwd_field",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_pwd_field),
		   OR_AUTHCFG,
		   "The name of the password field."),

    AP_INIT_TAKE1 ("Auth_PG_uid_field",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_uname_field),
		   OR_AUTHCFG,
		   "The name of the user-id field."),

    AP_INIT_TAKE1 ("Auth_PG_gid_field",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_grp_field),
		   OR_AUTHCFG,
		   "The name of the group-name field."),

    AP_INIT_FLAG ("Auth_PG_nopasswd",
		  ap_set_flag_slot,
		  (void *) APR_OFFSETOF (config_auth_gforge_state,
					 auth_pg_nopasswd),
		  OR_AUTHCFG,
		  "Accept no passwd: 'on' or 'off'"),

    AP_INIT_FLAG ("Auth_PG_encrypted",
		  ap_set_flag_slot,
		  (void *) APR_OFFSETOF (config_auth_gforge_state,
					 auth_pg_encrypted),
		  OR_AUTHCFG,
		  "Password encrypted: 'on' or 'off'"),

    AP_INIT_TAKE1 ("Auth_PG_hash_type",
		   pg_set_hash_type,
		   NULL,
		   OR_AUTHCFG,
		   "Password hash type (CRYPT|MD5)."),

    AP_INIT_TAKE1 ("Auth_default_access_type",
		   set_default_access_type,
		   NULL,
		   OR_AUTHCFG,
		   "Default Access Type: (FORBID|DECLINE)"),
 
    AP_INIT_TAKE1 ("Auth_default_author_type",
		   set_default_author_type,
		   NULL,
		   OR_AUTHCFG,
		   "Default Authorization Type: (FORBID|DECLINE)" ),

    AP_INIT_FLAG ("Auth_PG_cache_passwords",
		  ap_set_flag_slot,
		  (void *) APR_OFFSETOF (config_auth_gforge_state,
					 auth_pg_cache_passwords),
		  OR_AUTHCFG,
		  "'on' or 'off'"),

    AP_INIT_FLAG ("Auth_PG_authoritative",
		  ap_set_flag_slot,
		  (void *) APR_OFFSETOF (config_auth_gforge_state,
					 auth_pg_authoritative),
		  OR_AUTHCFG,
		  "'on' or 'off'"),
    AP_INIT_FLAG ("Auth_PG_lowercase_uid",
		  pg_set_lowercaseuid_flag,
		  NULL,
		  OR_AUTHCFG,
		  "'on' or 'off'"),

    AP_INIT_FLAG ("Auth_PG_uppercase_uid",
		  pg_set_uppercaseuid_flag,
		  NULL,
		  OR_AUTHCFG,
		  "'on' or 'off'"),

    AP_INIT_FLAG ("Auth_PG_pwd_ignore_case",
		  ap_set_flag_slot,
		  (void *) APR_OFFSETOF (config_auth_gforge_state,
					 auth_pg_pwdignorecase),
		  OR_AUTHCFG,
		  "'on' or 'off'"),

    AP_INIT_TAKE1 ("Auth_PG_grp_whereclause",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_grp_whereclause),
		   OR_AUTHCFG,
		   "An SQL fragment that can be attached to the end of a where"
		   "clause."),

    AP_INIT_TAKE1 ("Auth_PG_pwd_whereclause",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_pwd_whereclause),
		   OR_AUTHCFG,
		   "An SQL fragment that can be attached to the end of a where"
		   "clause."),

    AP_INIT_TAKE1 ("Auth_PG_log_table",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_log_table),
		   OR_AUTHCFG,
		   "The name of the table containing the log."),

    AP_INIT_TAKE1 ("Auth_PG_log_addrs_field",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_log_addrs_field),
		   OR_AUTHCFG,
		   "The name of the field containing addrs in the log table"
		   "(type char )."),

    AP_INIT_TAKE1 ("Auth_PG_log_uname_field",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_log_uname_field),
		   OR_AUTHCFG,
		   "The name of the field containing username in the log table (type char)."),

    AP_INIT_TAKE1 ("Auth_PG_log_pwd_field",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_log_pwd_field),
		   OR_AUTHCFG,
		   "the name of the field containing password in the log table (type char)."),
    AP_INIT_TAKE1 ("Auth_PG_log_date_field",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_log_date_field),
		   OR_AUTHCFG,
		   "the name of the field containing date in the log table (type char)."),
    AP_INIT_TAKE1 ("Auth_PG_log_uri_field",
		   ap_set_string_slot,
		   (void *) APR_OFFSETOF (config_auth_gforge_state,
					  auth_pg_log_uri_field),
		   OR_AUTHCFG,
		   "the name of the field containing uri (Object fetched) in the log"
		   "table (type char)."),

    AP_INIT_FLAG ("First_Letter",
		  ap_set_flag_slot,
		  (void *) APR_OFFSETOF (config_auth_gforge_state,
					 first_letter),
		  OR_AUTHCFG,
		  "First letter enabled: 'on' or 'off'" ),

    {NULL}
};
