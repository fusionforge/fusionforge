/**
 * Apache module for Gforge
 * This module provides authentication and authorization
 * in a Location supporting projects path
 *
 *  Types.h file
 *
 * @author    Francisco Gimeno <kikov @ fco-gimeno.com>
 * @date      2004-02-19
 * @see
 *
 *
 */

 /*
    * Constants
  */

#ifndef _TYPES_H_
#define _TYPES_H_

#include <httpd.h>

#ifndef MAX_STRING_LEN
#define MAX_STRING_LEN 3000
#endif

#ifndef MAX_TABLE_LEN
#define MAX_TABLE_LEN 50
#endif

#define AUTH_PG_HASH_TYPE_CRYPT 	1
#define AUTH_PG_HASH_TYPE_MD5 		2

enum
{
    AUTH_DEFAULT_ACCESS_TYPE_FORBID = HTTP_FORBIDDEN,
    AUTH_DEFAULT_ACCESS_TYPE_DECLINE = DECLINED,
    AUTH_DEFAULT_ACCESS_TYPE_UNKNOWN = DECLINED
};

enum
{
    AUTHZ_NONE = 0,
    AUTHZ_READ,
    AUTHZ_WRITE
};

enum
{
    ROOT_DIR = 0,
    USERS_DIR,
    GROUPS_DIR,
    UNKNOWN_DIR
};

/* We need Apache 1.3.1 */
#if (MODULE_MAGIC_NUMBER >= 19980713)
#define _const const
#define IS_APACHE_13         1
#endif

/* The structure that keep the Settings in Apache */
typedef struct
{
    char *gforgeSysPath;
    char *gforgeGroupsRoot;
    char *gforgeUsersRoot;
    char *gforgeAuthClause;
    char *gforgeReadClause;
    char *gforgeWriteClause;
    char *gforgeAnonClause;
    char *auth_pg_host;
    char *auth_pg_database;
    char *auth_pg_port;
    char *auth_pg_options;
    char *auth_pg_user;
    char *auth_pg_pwd;
    char *auth_pg_pwd_table;
    char *auth_pg_grp_table;
    char *auth_pg_uname_field;
    char *auth_pg_pwd_field;
    char *auth_pg_grp_field;
    char *auth_pg_pwd_whereclause;
    char *auth_pg_grp_whereclause;

    int auth_pg_nopasswd;
    int auth_pg_authoritative;
    int auth_pg_lowercaseuid;
    int auth_pg_uppercaseuid;
    int auth_pg_pwdignorecase;
    int auth_pg_encrypted;
    int auth_pg_hash_type;
    int auth_pg_cache_passwords;
    int auth_default_access_type;
    int auth_default_author_type;

    char *auth_pg_log_table;
    char *auth_pg_log_addrs_field;
    char *auth_pg_log_uname_field;
    char *auth_pg_log_pwd_field;
    char *auth_pg_log_date_field;
    char *auth_pg_log_uri_field;

    const char *base_path;
    
    int first_letter;

    apr_table_t *cache_pass_table;
    /* TODO */
    apr_table_t *cache_group_active_table;
    apr_table_t *cache_group_public_table;
    apr_table_t *cache_user_active_table;
    apr_table_t *cache_siteadmin_table;


}
config_auth_gforge_state;

#endif
