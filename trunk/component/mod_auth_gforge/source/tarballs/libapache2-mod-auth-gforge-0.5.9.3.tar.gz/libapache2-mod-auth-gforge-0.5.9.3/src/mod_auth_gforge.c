/**
 * Apache module for Gforge
 * This module provides authentication and authorization
 * in a Location supporting projects path
 *
 * @author    Francisco Gimeno <kikov @ kikov.org>
 * @date      2004-02-19
 * @see
 *
 *
 */


/*
 *  This software is a contribution to and make use of the Apache
 *  HTTP server which is written, maintained and copywritten by
 *  the Apache Group.
 *  See http://www.apache.org/ for more information.
 *
 *  This software make use of libpq which is an interface to the
 *  PostgrSQL database. PostgreSQL is copyright (c) 1994 by the
 *  Regents of the University of California. As of this writing, more
 *  information on PostgreSQL can be found at http://www.postgresql.org/
 */


/*
 *  Gforge authentication instruction
 *
 *  Needs libpq-fe.h and libpq.a for compilation
 *
 *  Outline:
 *  -Authentication
 *  One database, and one (or two) tables. One table holds the username
 *  and the encrypted (or plain) password. The other table holds the
 *  username and the names of the roup to which the user belongs. It is
 *  possible to have username, roupname and password in the same table.
 *  -Access Logging
 *  Every authentication access is logged in the same database of the
 *  authentication table, but in different table.
 *  User name and date of the request are logged. As option, it can log
 *  password, ip addresses, and request line.
 *  -Authorization
 *  See the README
 *
 *
 */


#include "../lconfig.h"

#include "debug.h"
#include "types.h"
#include "database.h"
#include "apacheconfig.h"
#include "utils.h"

#include "httpd.h"
#include "http_config.h"
#include "http_protocol.h"
#include "http_core.h"
#include "http_log.h"
#include "http_protocol.h"
#include "http_request.h"
#include "apr_uri.h"
#include "apr_pools.h"
#include "apr_lib.h"
#include "apr_strings.h"

#include "mod_dav_svn.h"

#include <libpq-fe.h>
#include <string.h>

#include <unistd.h>

#define AUTH_GFORGE_VERSION MOD_AUTH_GFORGE_PACKAGE_VERSION

int
pg_log_auth_user (request_rec * r, config_auth_gforge_state * sec, char *user,
		  char *sent_pw);

int
check_x_clause (request_rec * r, char *orig_clause, char *uri, int access_type,
		                char *real_group);

int
check_read_clause (request_rec * r, char *uri, int access_type,
		                   char *real_group);

int
check_write_clause (request_rec * r, char *uri, int access_type,
		                    char *real_group);

int
check_anon_clause (request_rec * r, char *uri, int access_type,
		                   char *real_group);

int
check_clause (request_rec * r, int kind, char *uri, char *user_dir,
		              char *real_group);

apr_pool_t *auth_gforge_pool = NULL;

module auth_gforge_module;

char gforgeErrorStr[MAX_STRING_LEN];
extern char pg_errstr[MAX_STRING_LEN];


char *
get_pg_pw (request_rec * r, char *user, config_auth_gforge_state * sec)
{
    char query[MAX_STRING_LEN];
    char safe_user[1 + 2 * strlen (user)];
    int n;

    pg_check_string (safe_user, user, strlen (user));

    if ((!sec->auth_pg_pwd_table) ||
	(!sec->auth_pg_pwd_field) || (!sec->auth_pg_uname_field))
    {
	snprintf (pg_errstr, MAX_STRING_LEN,
		  "PG: Missing parameters for password lookup: %s%s%s",
		  (sec->auth_pg_pwd_table ? "" : "Password table "),
		  (sec->auth_pg_pwd_field ? "" : "Password field name "),
		  (sec->auth_pg_uname_field ? "" : "UserID field name "));
	return NULL;
    };

    if (sec->auth_pg_lowercaseuid)
    {
	/* and force it to lowercase */
	n = 0;
	while (safe_user[n] && n < (MAX_STRING_LEN - 1))
	{
	    if (isupper (safe_user[n]))
	    {
		safe_user[n] = tolower (safe_user[n]);
	    }
	    n++;
	}
    }

    if (sec->auth_pg_uppercaseuid)
    {
	/* and force it to uppercase */
	n = 0;
	while (safe_user[n] && n < (MAX_STRING_LEN - 1))
	{
	    if (islower (safe_user[n]))
	    {
		safe_user[n] = toupper (safe_user[n]);
	    }
	    n++;
	}
    }

    n = snprintf (query, MAX_STRING_LEN, "select %s from %s where %s='%s' %s",
		  sec->auth_pg_pwd_field,
		  sec->auth_pg_pwd_table,
		  sec->auth_pg_uname_field,
		  safe_user,
		  sec->auth_pg_pwd_whereclause ? sec->
		  auth_pg_pwd_whereclause : "");

    if (n < 0 || n > MAX_STRING_LEN)
    {
	snprintf (pg_errstr, MAX_STRING_LEN,
		  "PG: Detected SQL-truncation attack. Auth aborted.");
	return NULL;
    }
    return do_pg_query (r, query, sec);
}

char *
get_pg_grp (request_rec * r, char *group, char *user,
	    config_auth_gforge_state * sec)
{
    char query[MAX_STRING_LEN];
    char safe_user[1 + 2 * strlen (user)];
    char safe_group[1 + 2 * strlen (group)];
    int n;

    query[0] = '\0';
    pg_check_string (safe_user, user, strlen (user));
    pg_check_string (safe_group, group, strlen (group));

    if ((!sec->auth_pg_grp_table) ||
	(!sec->auth_pg_grp_field) || (!sec->auth_pg_uname_field))
    {
	snprintf (pg_errstr, MAX_STRING_LEN,
		  "PG: Missing parameters for password lookup: %s%s%s",
		  (sec->auth_pg_grp_table ? "" : "Group table "),
		  (sec->auth_pg_grp_field ? "" : "GroupID field name "),
		  (sec->auth_pg_uname_field ? "" : "UserID field name "));
	return NULL;
    };

    n = snprintf (query, MAX_STRING_LEN,
		  "select %s from %s where %s='%s' and %s='%s' %s",
		  sec->auth_pg_grp_field, sec->auth_pg_grp_table,
		  sec->auth_pg_uname_field, safe_user, sec->auth_pg_grp_field,
		  safe_group,
		  sec->auth_pg_grp_whereclause ? sec->
		  auth_pg_grp_whereclause : "");

    if (n < 0 || n > MAX_STRING_LEN)
    {
		snprintf (pg_errstr, MAX_STRING_LEN,
			  "PG: Detected SQL-truncation attack. Auth aborted.");
		return NULL;
    }

    return do_pg_query (r, query, sec);
}


/**
 * Module initializer
 *
 * It just add version component to Apache
 */
int
init_module_gforge (apr_pool_t * p, apr_pool_t * ptemp, apr_pool_t * plog,
		    server_rec * s)
{
    if (auth_gforge_pool == NULL)
	apr_pool_sub_make (&auth_gforge_pool, NULL, NULL);

    DBG ("[mod_auth_gforge.c] GFORGE_AUTH: Init");
    ap_add_version_component (p, "mod_auth_gforge/" AUTH_GFORGE_VERSION);
    return OK;
}

/*
 * Process authentication request from Apache
 *
 * Authentication: request and test the Users Password
 *
 **/
int
pg_authenticate_basic_user (request_rec * r)
{
    config_auth_gforge_state *sec =
	(config_auth_gforge_state *) ap_get_module_config (r->per_dir_config,
							   &auth_gforge_module);
	//    conn_rec *c = r->connection; Not used at the moment
    char *val = NULL;
    char *user;
    char *sent_pw, *real_pw;
    int res;

    user = r->user;
    if ((res = ap_get_basic_auth_pw (r, (const char **) &sent_pw)))
	return res;

    /* if *password* checking is configured in any way, i.e. then
     * handle it, if not decline and leave it to the next in line..
     * We do not check on dbase, group, userid or host name, as it is
     * perfectly possible to only do group control and leave
     * user control to the next guy in line.
     */
    if ((!sec->auth_pg_pwd_table) && (!sec->auth_pg_pwd_field))
	return sec->auth_default_access_type;

    pg_errstr[0] = '\0';

    DBG ("[mod_auth_gforge.c] Basic Authentication Init");
    DBG ("[mod_auth_gforge.c] =========================");
    if (sec->auth_pg_cache_passwords
	&& (!apr_is_empty_table (sec->cache_pass_table)))
    {
	val = (char *) apr_table_get (sec->cache_pass_table, user);

	if (val)
	    real_pw = val;
	else
	    real_pw = get_pg_pw (r, user, sec);
    }
    else
	real_pw = get_pg_pw (r, user, sec);

    if (!real_pw)
    {
	if (pg_errstr[0])
	{
	    res = HTTP_INTERNAL_SERVER_ERROR;
	}
	else
	{
	    if (sec->auth_pg_authoritative)
	    {
		/* force error and access denied */
		snprintf (pg_errstr, MAX_STRING_LEN,
			  "mod_auth_gforge: Password for user %s not found"
			  "(PG-Authoritative)", r->user);
		ERR ("[mod_auth_gforge.c] %s", pg_errstr);
		ap_note_basic_auth_failure (r);
		res = HTTP_UNAUTHORIZED;
	    }
	    else
	    {
		return DECLINED;
	    }
	}
	DBG ("[mod_auth_gforge]: pg_authenticate_basic_user %s", pg_errstr);
	return res;
    }

    /* allow no password, if the flag is set and the password
     * is empty. But be sure to log this.
     */
    if ((sec->auth_pg_nopasswd) && (!strlen (real_pw)))
    {
	snprintf (pg_errstr, MAX_STRING_LEN,
		  "Gforge: user %s: Empty password accepted", r->user);
	pg_log_auth_user (r, sec, r->user, sent_pw);
	return OK;
    };
    /* if the flag is off however, keep that kind of stuff at
     * an arms length.
     */
    if ((!strlen (real_pw)) || (!strlen (sent_pw)))
    {
	snprintf (pg_errstr, MAX_STRING_LEN,
		  "Gforge: user %s: Empty Password(s) Rejected", r->user);
	ERR ("[mod_auth_gforge: %s", pg_errstr);
	ap_note_basic_auth_failure (r);
	return HTTP_UNAUTHORIZED;
    };

    if (sec->auth_pg_encrypted)
	sent_pw = (sec->auth_pg_hash_type == AUTH_PG_HASH_TYPE_MD5) ?
	    auth_pg_md5 (sent_pw) : (char *) crypt (sent_pw, real_pw);

    if ((sec->auth_pg_hash_type == AUTH_PG_HASH_TYPE_MD5 ||
	 sec->auth_pg_pwdignorecase != 0) ? strcasecmp (real_pw, sent_pw) :
	strcmp (real_pw, sent_pw))
    {
	snprintf (pg_errstr, MAX_STRING_LEN,
		  "Gforge user %s: password mismatch", r->user);
	ERR ("[mod_auth_gforge: %s", pg_errstr);
	ap_note_basic_auth_failure (r);
	return HTTP_UNAUTHORIZED;
    }

    /* store password in the cache */
    if (sec->auth_pg_cache_passwords && !val && sec->cache_pass_table)
    {
	if ((apr_table_elts (sec->cache_pass_table))->nelts >= MAX_TABLE_LEN)
	    apr_table_clear (sec->cache_pass_table);
	apr_table_set (sec->cache_pass_table, user, real_pw);
    }

    DBG ("[mod_auth_gforge.c] User %s, AUTHENTICATED", user);
    pg_log_auth_user (r, sec, user, sent_pw);

    return OK;
}

int
validate_user (request_rec * r)
{
    return pg_authenticate_basic_user (r);
}


/**
 *	int check_group_auth (request_rec *r, char *uri)
 *
 *  @desc is the user allow in this group?
 *		It check if the group is active,
 *		the user is in the group,
 *		if he is going to read or write
 *  @param r The apache request
 *  @param uri The uri to check
 *	@return true if the user can make what requested
 */
int
check_group_auth (request_rec * r, char *uri)
{
    /* Variable declaration */
    char *real_group, *user;
    int authz_type;
/*    int n;
    apr_array_header_t *reqs_arr;
    require_line *reqs; */ // Not used at the moment
    config_auth_gforge_state *sec;
    real_group = NULL;

    DBG ("[mod_auth_gforge.c] CHECK AUTHORIZATION INTO GROUP_DIR INIT");
    DBG ("[mod_auth_gforge.c] =======================================");
    DBG ("[mod_auth_gforge.c] Requested Uri: %s", uri);

    /* Get the Config for this request */
    sec =
	(config_auth_gforge_state *) ap_get_module_config (r->per_dir_config,
							   &auth_gforge_module);
    user = r->user;

    real_group = extract_group_from_uri (sec, r, uri);

    DBG ("[mod_auth_gforge.c] 1. Check if the user is Site Admin");
    if (is_user_siteadmin (sec, user, r))
    {
	DBG ("[mod_auth_gforge.c] 1.a. User is Site ADMIN. ACCESS GRANTED");
	return OK;
    }
    DBG ("[mod_auth_gforge.c] 1.b. User is not Site ADMIN. Go to 2");

    DBG ("[mod_auth_gforge.c] 2. Check if the Project Exists");
    if (real_group == NULL)
    {
	DBG ("[mod_auth_gforge.c] 2.b.If doesn't exists. (Group not "
	     "controlled by me!)");
	return sec->auth_default_author_type;
    }
    else
    {
	DBG ("[mod_auth_gforge.c] 2.a.If exists (Group controlled by "
	     "me!)");
    }
    DBG ("[mod_auth_gforge.c] 3. Check if Group is ACTIVE");
    if (!group_active (sec, real_group, r))
    {
	DBG ("[mod_auth_gforge.c] 3.a. Sorry, the group %s is not active."
	     " HTTP_FORBIDDEN", real_group);
	return HTTP_FORBIDDEN;
    }
    DBG ("[mod_auth_gforge.c] 3.b. Group is active. Go to 4");


    DBG ("[mod_auth_gforge.c] 4. Check if the Group is Public");
    if (is_group_public (sec, real_group, r))
    {
	DBG ("[mod_auth_gforge.c] 4.a. Group is public");
    }
    else
    {
	DBG ("[mod_auth_gforge.c] 4.b. Group is not public, checking if user %s"
	     " is in group %s", user, real_group);
	if (group_contains_user (sec, real_group, user, r) == TRUE)
	{
	    DBG ("[mod_auth_gforge.c] 4.b.1. User %s is in group"
		 "%s", user, real_group);
	}
	else
	{
	    DBG ("[mod_auth_gforge.c] 4.b.2. User %s isn't in group %s."
		 "HTTP_FORBIDDEN", user, real_group);
	    return HTTP_FORBIDDEN;
	}
    }
    authz_type = gforge_access_method (r->method_number);

    DBG ("[mod_auth_gforge.c] 5. Checking General Clause");
    if (check_clause (r, authz_type, uri, NULL, real_group) == FALSE)
    {
	DBG ("[mod_auth_gforge.c] 5.a General Clause not passed");
	return HTTP_FORBIDDEN;
    }
    else
    {
	DBG ("[mod_auth_gforge.c] 5.b General Clause passed");
    }
    DBG ("[mod_auth_gforge.c] 6.Group Admin?");
    if (user_is_groupadmin (sec, user, real_group, r))
    {
	DBG ("[mod_auth_gforge.c] 6.a Group Admin Allowed. ACCESS GRANTED");
	return OK;
    }
    else
	DBG ("[mod_auth_gforge.c] 6.b User is not a GroupAdmin");

    DBG ("[mod_auth_gforge.c] 7. Checking ACCESS TYPE: "
	 "authz_type_requested=%d,%d", authz_type, r->method_number);

    DBG("[mod_auth_gforge.c] 7.a. Checking if user is member");
     if (user_is_member(sec, user, real_group, r))
     {
		DBG("[mod_auth_gforge.c] 7.a.1. User is member");
		if (authz_type == AUTHZ_READ)
		{
			DBG("[mod_auth_gforge.c] 7.a.1.a) Read Access?");
			if (check_read_clause (r, uri, authz_type, real_group) == TRUE)
			{
				DBG ("[mod_auth_gforge.c] 7.a.2.a Read "
					"Clause Passed. ACCESS GRANTED");
				return OK;
			}
			else
			{
				DBG ("[mod_auth_gforge.c] 7.a.2.b Read "
					"Clause Not Passed. HTTP_FORBIDDEN");
				return HTTP_FORBIDDEN;
			}
		}
		if (authz_type == AUTHZ_WRITE)
		{
			DBG ("[mod_auth_gforge.c] 7.a.1.b) Write Access?");

			if (sec->gforgeWriteClause
	    		&& check_write_clause (r, uri, authz_type, real_group) == TRUE)
			{
	    			DBG ("[mod_auth_gforge.c] 7.a.1.b Write Clause Passed."
					" ACCESS GRANTED");
	    			return OK;
			}
			else
			{
	    			DBG ("[mod_auth_gforge.c] 7.b.2 Write Clause Not Passed."
					" HTTP_FORBIDDEN");
	    			return HTTP_FORBIDDEN;
			}
		}
     } else {
     		DBG("[mod_auth_gforge.c] 7.a.2 User is not member or he is anonymous");
		if (is_group_public (sec, real_group, r) && authz_type == AUTHZ_READ)
		{
			DBG ("[mod_auth_gforge.c] 7.a.2 User is not member");
			if (check_anon_clause (r, uri, authz_type, real_group) == TRUE)
			{
				DBG ("[mod_auth_gforge.c] 7.a.2.a Anonymous Clause Passed."
					" ACCESS GRANTED");
				return OK;
			}
			else
			{
				DBG ("[mod_auth_gforge.c] 7.a.1.b Anonymous Clause Not "
				"Passed. FORBIDDEN!");
				return HTTP_FORBIDDEN;
			}
		} else {
			DBG("[mod_auth_gforge.c] 7.a.2 Private Group. User should be member "
				" of group to read Private Groups or to Write to Public Groups");
			return HTTP_FORBIDDEN;
		}
   }

    
    return sec->auth_default_author_type;
}

/**
 *  int check_userdir_auth (request_rec *r, char *uri)
 *
 *  @desc is the user allow in this user homedir?
 *     It check if the user is active,
 *     the user is the owner,
 *     if he is going to read or write
 *  @param r The apache request
 *  @param uri The URI to check
 *
 *  @return OK if the user can make what requested
 *          FORBID if the action is FORBIDDEN
 *	    DECLINE if we can't choose what to do with it
 */
int
check_userdir_auth (request_rec * r, char *uri)
{
    /* Variable declaration */
    const char *userdir, *user;
    int authz_type;
    config_auth_gforge_state *sec;
    userdir = NULL;

    DBG ("[mod_auth_gforge.c] CHECK AUTHORIZATION IN USERSDIR INIT");
    DBG ("[mod_auth_gforge.c] ====================================");

    /* Get the Config for this request */
    sec =
	(config_auth_gforge_state *) ap_get_module_config (r->per_dir_config,
							   &auth_gforge_module);
    user = r->user;

    userdir = extract_user_from_uri (sec, r, uri);
    DBG ("[mod_auth_gforge.c] Owner of dir to be visited: %s", userdir);

    DBG ("[mod_auth_gforge.c] 1. Check if the User %s Exists", userdir);
    if (userdir == NULL)
    {
	DBG ("[mod_auth_gforge.c] 1.b.If doesn't exists. (User not "
	     "controlled by me!)");
	return sec->auth_default_author_type;
    }
    else
    {
	DBG ("[mod_auth_gforge.c] 1.a.If exists (User controlled by" " me!)");
    }

    if (is_user_siteadmin (sec, user, r))
    {
	DBG ("[mod_auth_gforge.c] 2. if ( User==admin ) Access " "granted");
	return OK;
    }
    /* Now, the User exists */
    DBG ("[mod_auth_gforge.c] 2. Check if the user is Active");
    if (!user_active (sec, userdir, r))
    {

	DBG ("[mod_auth_gforge.c] 2.b. Sorry, the user %s is not active",
	     userdir);
	return HTTP_FORBIDDEN;
    }
    else
    {

	DBG ("[mod_auth_gforge.c] 2.a. User is active");
    }

    DBG ("[mod_auth_gforge.c] 3. Check if directory is private:");
    if (is_private_dir (sec, r, uri))
    {
	DBG ("[mod_auth_gforge.c] 3.1. Dir is private");
	if (strcmp (user, userdir) != 0)
	{			/* Non-owner */
	    DBG ("[mod_auth_gforge.c] 3.2. And %s is not %s", user, userdir);
	    return HTTP_FORBIDDEN;
	}
    }

    authz_type = gforge_access_method (r->method_number);
    DBG ("[mod_auth_gforge.c] 4. Check Access Required:"
	 "authz_type_requested=%d", authz_type);
    if (authz_type == AUTHZ_READ)
    {
	DBG ("[mod_auth_gforge.c] 4.a. Check if Read Acess");
	DBG ("[mod_auth_gforge.c] Access GRANTED");
	return OK;
    }
    else if (authz_type == AUTHZ_WRITE)
    {

	if (strcmp (user, userdir) == 0)
	{
	    DBG ("[mod_auth_gforge.c] 4.b. User is himself");
	    DBG ("[mod_auth_gforge.c] Access GRANTED");
	    return OK;
	}
	else
	{
	    DBG ("[mod_auth_gforge.c] 4.c. User is not owner");
	    return HTTP_FORBIDDEN;
	}

    }
    else
    {				/* Unknown Access */
	return HTTP_FORBIDDEN;
    }

    return sec->auth_default_author_type;
}



int
check_x_clause (request_rec * r, char *orig_clause, char *uri, int access_type,
		char *real_group)
{
    config_auth_gforge_state *sec;
    char *clause = NULL;
    char query[MAX_STRING_LEN];
    char *s = NULL;


    DBG ("[mod_auth_gforge.c] CHECK_X_CLAUSE");
    DBG ("[mod_auth_gforge.c] =================");

    sec =
	(config_auth_gforge_state *) ap_get_module_config (r->per_dir_config,
							   &auth_gforge_module);
    if (orig_clause == NULL)
    {
	DBG ("[mod_auth_gforge.c] No clause defined. ");
	return TRUE;
    }
    clause =
	get_clause (r->pool, orig_clause, uri, access_type, r->user,
		    real_group);
    if (clause != NULL)
    {
	snprintf (query, MAX_STRING_LEN,
		  "SELECT user_group_id FROM users,groups,user_group "
		  "WHERE user_group.group_id=groups.group_id AND "
		  "user_group.user_id=users.user_id AND "
		  "users.user_name = '%s' AND "
		  "groups.unix_group_name = '%s' AND "
		  "user_group.%s", r->user, real_group, clause);
	s = (char *) do_pg_query (r, query, sec);
    }

    if (s == NULL)
    {
	DBG ("[mod_auth_gforge.c] Clause Not Passed. Query: %s", query);
	return FALSE;
    }
    else
	return TRUE;
}

int
check_read_clause (request_rec * r, char *uri, int access_type,
		   char *real_group)
{
    config_auth_gforge_state *sec;
    DBG ("[mod_auth_gforge.c] CHECK_READ_CLAUSE");
    sec =
	(config_auth_gforge_state *) ap_get_module_config (r->per_dir_config,
							   &auth_gforge_module);
    return check_x_clause (r, sec->gforgeReadClause, uri, access_type,
			   real_group);
}

int
check_write_clause (request_rec * r, char *uri, int access_type,
		    char *real_group)
{
    config_auth_gforge_state *sec;
    DBG ("[mod_auth_gforge.c] CHECK_WRITE_CLAUSE");
    sec =
	(config_auth_gforge_state *) ap_get_module_config (r->per_dir_config,
							   &auth_gforge_module);
    return check_x_clause (r, sec->gforgeWriteClause, uri, access_type,
			   real_group);
}

int
check_anon_clause (request_rec * r, char *uri, int access_type,
		   char *real_group)
{
    config_auth_gforge_state *sec;
    char *clause = NULL, *s = NULL;
    char query[MAX_STRING_LEN];

    DBG ("[mod_auth_gforge.c] CHECK_ANON_CLAUSE");
    sec =
	(config_auth_gforge_state *) ap_get_module_config (r->per_dir_config,
							   &auth_gforge_module);
    if (sec->gforgeAnonClause == NULL)
    {
	DBG ("[mod_auth_gforge.c] No clause defined. ");
	return TRUE;
    }

    clause =
	get_clause (r->pool, sec->gforgeAnonClause, uri, access_type, r->user,
		    real_group);
    if (clause != NULL)
    {
	snprintf (query, MAX_STRING_LEN,
		  "SELECT group_id FROM groups,users "
		  "WHERE groups.unix_group_name = '%s' AND "
		  "users.user_name = '%s' AND "
		  "%s", real_group, r->user, clause);
	s = (char *) do_pg_query (r, query, sec);
    }

    if (s == NULL)
    {
	DBG ("[mod_auth_gforge.c] AnonClause Not Passed. Query: %s", query);
	return FALSE;
    }
    else
	return TRUE;
}

/**
 *  int check_clause ( request_rec *r, int kind,char *uri, char *user_dir,
 *			char *real_group )
 *
 *  @desc is the user allow here?
 *  @param r request
 *  @param kind kind of petition ( 0= ROOTDIR, 1=UsersDir, 2=GroupsDir )
 *  @param uri  The URI to check
 *  It should check if the access is allowed,
 *  through a clause in directive.
 *
 *  $G is substituted by group_id of the accessed path ( ONLY in kind 2 )
 *  $U is substituted by user_id
 *  $u is substituted by user_id of the accessed path ( ONLY in kind 1 )
 *
 *  write (  has the user enough privileges? )
 *  @return false if the clause don't allow the access
 */
int
check_clause (request_rec * r, int kind, char *uri, char *user_dir,
	      char *real_group)
{
    config_auth_gforge_state *sec;
    char *clause;
    char *s = NULL;
    char method[MAX_STRING_LEN];

    DBG ("[mod_auth_gforge.c] CHECK_CLAUSE");
    DBG ("[mod_auth_gforge.c] ============");
    /* Get the Config for this request */
    sec =
	(config_auth_gforge_state *) ap_get_module_config (r->per_dir_config,
							   &auth_gforge_module);
    if (sec->gforgeAuthClause == NULL)
    {
	DBG ("[mod_auth_gforge.c] No clause defined. ");
	return TRUE;
    }
    clause = (char *) apr_pstrdup (r->pool, sec->gforgeAuthClause);
    DBG ("[mod_auth_gforge.c]  Original clause: %s", sec->gforgeAuthClause);

    if (kind == 2 && real_group)
	clause = string_substitute (r->pool, clause, "$G", real_group);

    if (kind == 1 && user_dir)
	clause = string_substitute (r->pool, clause, "$u", user_dir);


    sprintf (method, "WRITE");	// Default

    if (gforge_access_method (r->method_number) == AUTHZ_WRITE)
	sprintf (method, "WRITE");
    if (gforge_access_method (r->method_number) == AUTHZ_READ)
	sprintf (method, "READ");

    clause = string_substitute (r->pool, clause, "$U", r->user);
    clause = string_substitute (r->pool, clause, "$A", method);
    DBG ("[mod_auth_gforge.c] clause: %s", clause);

    if (strstr (clause, "$G") == NULL && strstr (clause, "$u") == NULL)
    {
	s = do_pg_query (r, clause, sec);
	DBG ("[mod_auth_gforge.c]  Query done, %s", clause);
	if (s == NULL)
	    return FALSE;
	else
	    return TRUE;
    }
    DBG ("[mod_auth_gforge.c] Clause not applied,because fields couldn't be filled");
    return TRUE;
}


/**
 *  int check_auth (request_rec *r)
 *
 *  @desc is the user allow here?
 *   It should check if the project is active,
 *   the user is in the group,
 *   the authz_type: read ( for public projects ),
 *    write ( has the user enough privileges? )
 *  @return true if the user could make what requested
 */

int
check_auth (request_rec * r)
{
    /* Variable declaration */
    char *real_group, *user;
    const char *cleaned_uri, *repos_name, *relative_path, *repos_path;
    char uri[MAX_STRING_LEN];
    int n, kind;
    apr_array_header_t *reqs_arr;
    require_line *reqs;
    config_auth_gforge_state *sec;
    dav_error *dav_err;
    int trailing_slash;
    int is_svn_configured = TRUE;

    real_group = NULL;

    DBG ("[mod_auth_gforge.c] CHECK AUTHORIZATION INIT REQUEST");
    DBG ("[mod_auth_gforge.c] ================================");

    /* Get the Config for this request */
    sec =
	(config_auth_gforge_state *) ap_get_module_config (r->per_dir_config,
							   &auth_gforge_module);
    user = r->user;

    DBG ("[mod_auth_gforge.c] User: %s URI: %s Method: %d"
	 "", user, r->uri, r->method_number);

    dav_err = dav_svn_split_uri (r,
				 r->uri,
				 sec->base_path,
				 &cleaned_uri,
				 &trailing_slash,
				 &repos_name, &relative_path, &repos_path);
    if (dav_err)
    {
	if (dav_err->error_id != 190000)
	{
	    is_svn_configured = TRUE;
	    DBG ("[mod_auth_gforge.c] DAV ERROR: %s  [%d, #%d]",
		 dav_err->desc, dav_err->status, dav_err->error_id);
	    if (dav_err->error_id == 190001)
	    {
		DBG ("[mod_auth_gforge.c] Access to Root Allowed");
		return OK;
	    }
	    return sec->auth_default_author_type;
	}
	else
	{			/* Status_id == 190000 if SVNPath not defined */
	    /* SVN not configured */
	    DBG ("[mod_auth_gforge.c] Svn not configured");
	    is_svn_configured = FALSE;
	}
    }

    if ((is_svn_configured == TRUE && !dav_err))
    {
	uri[0] = '/';
	uri[1] = 0;
	DBG ("[mod_auth_gforge.c] Cleaned_URI:%s, Trailing_slash:%u, \
             repos_name:%s, relative_path:%s, repos_path:%s", cleaned_uri, trailing_slash, repos_name, relative_path, repos_path);
	if (repos_name != NULL && *repos_name != 0 && strlen (repos_name) != 1)
	{
	    DBG ("[mod_auth_gforge.c] Repos_name used as first part of URI");
	    uri[0] = 0;
	    strncat (uri, sec->gforgeGroupsRoot, MAX_STRING_LEN);
	    if ( sec->gforgeGroupsRoot[strlen(sec->gforgeGroupsRoot)-1] != '/' )
		    strncat(uri, "/", MAX_STRING_LEN);
	    strncat (uri, repos_name, MAX_STRING_LEN);
	    DBG ("[mod_auth_gforge.c] URI, now should be repos_name: %s",
		 uri);
	    if (repos_path != NULL)
	    {
		if (*repos_path != 0)
		{
		    DBG ("[mod_auth_gforge.c] repos_path != '', so we add a slash! ");
		    strncat (uri, "/", MAX_STRING_LEN);
		}
	    }
	}
	if (repos_path && strlen (repos_path) != 1)
	    strncat (uri, repos_path, MAX_STRING_LEN);
    }
    else
    {
	DBG ("[mod_auth_gforge.c] SVN not used, so falling in the normal way to get the Uri");
	uri[0] = 0;
	strncat (uri, r->uri, MAX_STRING_LEN);
    }

    DBG ("[mod_auth_gforge.c] Definitive URI to parse: %s", uri);
    /* Check the require lines
     *      At the moment I don't know how to deal with this
     */
    reqs_arr = (apr_array_header_t *) ap_requires (r);
    reqs = reqs_arr ? (require_line *) reqs_arr->elts : NULL;
    /* for (n = 0; n < reqs_arr->nelts; n++)
    {
	DBG ("[mod_auth_gforge.c] Require Lines: Element=%d,value=%s,%d",
	     n, reqs[n].requirement, reqs[n].method_mask);
    } */

    // gforgeSysPath has to be defined for executing the module
    if (sec->gforgeSysPath == NULL)
	return sec->auth_default_access_type;

    if (sec->gforgeUsersRoot == NULL && sec->gforgeGroupsRoot == NULL)
    {
	DBG ("[mod_auth_gforge.c] Either GforgeGroupsRoot or GforgeUsersRoot "
	     "must be defined in config file!!!");
	return sec->auth_default_author_type;
    }

    kind = get_kind_from_uri (sec, r, uri);
    DBG ("[mod_auth_gforge.c] Kind of URI "
	 "(0=Root,1=UsersDir,2=GroupsDir,3=UnknownDir): %d", kind);

    if (kind == ROOT_DIR || kind == UNKNOWN_DIR )
    {
	return OK;
    }
    else if (kind == GROUPS_DIR)
    {
	return check_group_auth (r, uri);
    }
    else if (kind == USERS_DIR)
    {
	return check_userdir_auth (r, uri);
    }

    return sec->auth_default_author_type;
}

/**
 *	int pg_log_auth_user (request_rec * r, config_auth_gforge_state * sec, char
 *		user,  char *sent_pw)
 *
 *  @desc Send the authentication to the log table
 *
 */
int
pg_log_auth_user (request_rec * r, config_auth_gforge_state * sec, char *user,
		  char *sent_pw)
{
    char sql[MAX_STRING_LEN];
    char *s;
    char fields[MAX_STRING_LEN];
    char values[MAX_STRING_LEN];
    char safe_user[1 + 2 * strlen (user)];
    char safe_pw[1 + 2 * strlen (sent_pw)];
    char safe_req[1 + 2 * strlen (r->the_request)];

    char ts[MAX_STRING_LEN];	/* time in string format */
    apr_time_exp_t t;		/* time of request start */
    apr_size_t retsize;

    /* we do not want to process internal redirect  */
    // DBG ("[mod_auth_gforge.c] pg_log_auth_user");
    if (!ap_is_initial_req (r))
	return sec->auth_default_access_type;
    if ((!sec->auth_pg_log_table) || (!sec->auth_pg_log_uname_field)
	|| (!sec->auth_pg_log_date_field))
    {				// At least table name, username and date field are specified
	// send error message and exit
	return sec->auth_default_access_type;
    }
    //DBG ("[mod_auth_gforge.c] checks passed ");
    /* AUD: MAX_STRING_LEN probably isn't always correct */
    pg_check_string (safe_user, user, strlen (user));
    pg_check_string (safe_pw, sent_pw, strlen (sent_pw));
    pg_check_string (safe_req, r->the_request, strlen (r->the_request));

    /* Time Field Format  */
    apr_time_exp_lt (&t, r->request_time);
    apr_strftime (ts, &retsize, 100, "%Y-%m-%d %H:%M:%S", &t);

    /* SQL Statement, required fields: Username, Date */
    snprintf (fields, MAX_STRING_LEN, "%s,%s",
	      sec->auth_pg_log_uname_field, sec->auth_pg_log_date_field);
    snprintf (values, MAX_STRING_LEN, "'%s','%s'", safe_user, ts);

    /* Optional parameters */
    if (sec->auth_pg_log_addrs_field)
    {				/* IP Address field */
	snprintf (sql, MAX_STRING_LEN, ", %s", sec->auth_pg_log_addrs_field);
	strncat (fields, sql, MAX_STRING_LEN - strlen (fields) - 1);
	snprintf (sql, MAX_STRING_LEN, ", '%s'", r->connection->remote_ip);
	strncat (values, sql, MAX_STRING_LEN - strlen (values) - 1);
    }
    if (sec->auth_pg_log_pwd_field)
    {				/* Password field , clear WARNING */
	snprintf (sql, MAX_STRING_LEN, ", %s", sec->auth_pg_log_pwd_field);
	strncat (fields, sql, MAX_STRING_LEN - strlen (fields) - 1);
	snprintf (sql, MAX_STRING_LEN, ", '%s'", safe_pw);
	strncat (values, sql, MAX_STRING_LEN - strlen (values) - 1);
    }
    if (sec->auth_pg_log_uri_field)
    {				/* request string */
	snprintf (sql, MAX_STRING_LEN, ", %s", sec->auth_pg_log_uri_field);
	strncat (fields, sql, MAX_STRING_LEN - strlen (fields) - 1);
	snprintf (sql, MAX_STRING_LEN, ", '%s'", safe_req);
	strncat (values, sql, MAX_STRING_LEN - strlen (values) - 1);
    }

    snprintf (sql, MAX_STRING_LEN, "insert into %s (%s) values(%s) ; ",
	      sec->auth_pg_log_table, fields, values);

    s = do_pg_query (r, sql, sec);
    return (0);
}

/* Init the module private memory pool, used for the per directory cache tables */
static void *
pg_auth_server_config (apr_pool_t * p, server_rec * s)
{
    DBG ("[mod_auth_gforge.c] ====> SERVER config INIT <==== ");

    if (auth_gforge_pool == NULL)
	apr_pool_create_ex (&auth_gforge_pool, NULL, NULL, NULL);
    return OK;
}

static void
register_hooks (apr_pool_t * p)
{
    ap_hook_post_config (init_module_gforge, NULL, NULL, APR_HOOK_MIDDLE);
    ap_hook_auth_checker (check_auth, NULL, NULL, APR_HOOK_FIRST);
    ap_hook_check_user_id (validate_user, NULL, NULL, APR_HOOK_MIDDLE);
}


/* Dispatch list for API hooks */
module AP_MODULE_DECLARE_DATA auth_gforge_module = {
    STANDARD20_MODULE_STUFF,
    create_dir_config,		/* create per-dir config structures    */
    NULL,			/* merge  per-dir    config structures */
    pg_auth_server_config,	/* create per-server config structures */
    NULL,			/* merge  per-server config structures */
    config_auth_gforge_cmds,	/* table of config file commands       */
    register_hooks,		/* register the hooks :)               */
};
