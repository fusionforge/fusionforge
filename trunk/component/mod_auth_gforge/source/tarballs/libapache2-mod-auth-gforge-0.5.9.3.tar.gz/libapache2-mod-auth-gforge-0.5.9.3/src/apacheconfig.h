/**
 * apacheconfig.h
 *
 * Apache module for Gforge
 * This module provides authentication and authorization
 * in a Location supporting projects path
 *
 * @author    Francisco Gimeno <kikov @ fco-gimeno.com>
 * @date      2004-02-19
 * @see
 *
 *
 *
 */

/*
 *  Apache Config Support Functions
 *
 *
 */

#ifndef _APACHECONFIG_H_
#define _APACHECONFIG_H_

#include "types.h"


#include <httpd.h>
#include <http_config.h>
#include <http_request.h>
#include <http_protocol.h>

extern apr_pool_t *auth_gforge_pool;
extern command_rec config_auth_gforge_cmds[];

void *create_dir_config (apr_pool_t * p, char *d);

_const char *pg_set_hash_type (cmd_parms * cmd, config_auth_gforge_state * sec,
			       const char *hash_type);
_const char *pg_set_cache_passwords_flag (cmd_parms * cmd,
					  config_auth_gforge_state * sec,
					  int arg);

_const char *pg_set_passwd_flag (cmd_parms * cmd,
				 config_auth_gforge_state * sec, int arg);

_const char *pg_set_encrypted_flag (cmd_parms * cmd,
				    config_auth_gforge_state * sec, int arg);

_const char *pg_set_authoritative_flag (cmd_parms * cmd,
					config_auth_gforge_state * sec,
					int arg);

_const char *pg_set_lowercaseuid_flag (cmd_parms * cmd,
				       config_auth_gforge_state * sec, int arg);
_const char *pg_set_uppercaseuid_flag (cmd_parms * cmd,
				       config_auth_gforge_state * sec, int arg);

_const char *pg_set_pwdignorecase_flag (cmd_parms * cmd,
					config_auth_gforge_state * sec,
					int arg);
void *make_config_auth_gforge (apr_pool_t * p, server_rec * s);



#endif
