/**
 * database.c
 *
 * Apache module for Gforge
 * This module provides authentication and authorization
 * in a Location supporting projects path
 *
 * @author    Francisco Gimeno <kikov @ fco-gimeno.com>
 * @date      2004-02-19
 * @see
 *
 *
 *
 */

/*
 *  Database Support Functions
 *
 *
 */
#include "types.h"
#include "debug.h"

#include <libpq-fe.h>
#include <string.h>
#include "http_config.h"
#include "http_protocol.h"
#include "http_core.h"
#include "http_log.h"
#include "http_protocol.h"
#include "http_request.h"
#include "apr_md5.h"
#include "apr_uri.h"
#include "apr_strings.h"

static PGconn *auth_pgsql_connection = NULL;

/*
 * the postgreSQL stuff
 */
char pg_errstr[MAX_STRING_LEN];
		 /* global errno to be able to handle config/sql
		  * failures separately
		  */

char *
auth_pg_md5 (char *pw)
{
    apr_md5_ctx_t ctx;
    unsigned char digest[16];
    static char md5hash[33];
    int i;

    apr_md5_init (&ctx);
    apr_md5_update (&ctx, pw, strlen (pw));
    apr_md5_final (digest, &ctx);

    for (i = 0; i < 16; i++)
	sprintf (&md5hash[i + i], "%02x", digest[i]);

    md5hash[32] = '\0';
    return md5hash;
}

/* Got from POstgreSQL 7.2 */
/* ---------------
 * Escaping arbitrary strings to get valid SQL strings/identifiers.
 *
 * Replaces "\\" with "\\\\" and "'" with "''".
 * length is the length of the buffer pointed to by
 * from.  The buffer at to must be at least 2*length + 1 characters
 * long.  A terminating NUL character is written.
 * ---------------
 */

size_t
pg_check_string (char *to, const char *from, size_t length)
{
    const char *source = from;
    char *target = to;
    unsigned int remaining = length;

    while (remaining > 0)
    {
	switch (*source)
	{
	case '\\':
	    *target = '\\';
	    target++;
	    *target = '\\';
	    /* target and remaining are updated below. */
	    break;

	case '\'':
	    *target = '\'';
	    target++;
	    *target = '\'';
	    /* target and remaining are updated below. */
	    break;

	default:
	    *target = *source;
	    /* target and remaining are updated below. */
	}
	source++;
	target++;
	remaining--;
    }

    /* Write the terminating NUL character. */
    *target = '\0';

    return target - to;
}


/* Do a query and return the (0,0) value.  The query is assumed to be
 * a select.
 */
char *
do_pg_query (request_rec * r, char *query, config_auth_gforge_state * sec)
{

    PGresult *pg_result;

    char *val;
    char *result = NULL;

    pg_errstr[0] = '\0';

    /* Validate current connection for current dir setting */
    if (!(auth_pgsql_connection == NULL))
    {
	if (!strcmp (sec->auth_pg_database, PQdb (auth_pgsql_connection)) &&
	    !strcmp (sec->auth_pg_user, PQuser (auth_pgsql_connection)))
	{
	    DBG ("[mod_auth_gforge.c] Connection is valid");
	}
	else
	{
	    PQfinish (auth_pgsql_connection);
	    auth_pgsql_connection = NULL;
	    DBG ("[mod_auth_gforge.c] Connection is NOT valid");
	}
    }				/* end connection validation */

    if (auth_pgsql_connection == NULL)
    {
	DBG ("[mod_auth_gforge.c] do_pg_query - going to connect database %s",
	     sec->auth_pg_database);

	auth_pgsql_connection =
	    PQsetdbLogin (sec->auth_pg_host, sec->auth_pg_port,
			  sec->auth_pg_options, NULL, sec->auth_pg_database,
			  sec->auth_pg_user, sec->auth_pg_pwd);
    }
    DBG ("[mod_auth_gforge.c] - End connecting");


    if (PQstatus (auth_pgsql_connection) != CONNECTION_OK)
    {
	PQreset (auth_pgsql_connection);
	apr_snprintf (pg_errstr, MAX_STRING_LEN,
		      "mod_auth_pgsql database connection error resetting %s",
		      PQerrorMessage (auth_pgsql_connection));
	DBG ("[mod_auth_gforge.c] %s", pg_errstr);
	if (PQstatus (auth_pgsql_connection) != CONNECTION_OK)
	{
	    apr_snprintf (pg_errstr, MAX_STRING_LEN,
			  "mod_auth_pgsql database connection error reset failed %s",
			  PQerrorMessage (auth_pgsql_connection));
	    DBG ("[mod_auth_gforge.c] %s", pg_errstr);
	    return NULL;
	}
    }

//    DBG ("[mod_auth_gforge.c] - do_pg_query - going to execute query %s ",
//       query);

    pg_result = PQexec (auth_pgsql_connection, query);
    if (pg_result == NULL)
    {
	snprintf (pg_errstr, MAX_STRING_LEN, "PGSQL 2: %s -- Query: %s",
		  PQerrorMessage (auth_pgsql_connection), query);
	DBG ("[mod_auth_gforge.c] %s", pg_errstr);
	PQfinish (auth_pgsql_connection);
	auth_pgsql_connection = NULL;
	return NULL;
    }

    if (PQresultStatus (pg_result) == PGRES_EMPTY_QUERY)
    {
	snprintf (pg_errstr, MAX_STRING_LEN, "PGSQL 2b: %s -- Query empty: %s",
		  PQerrorMessage (auth_pgsql_connection), query);
	DBG ("[mod_auth_gforge.c] %s", pg_errstr);
	PQclear (pg_result);
	PQfinish (auth_pgsql_connection);
	auth_pgsql_connection = NULL;
	return NULL;
    }

    if (PQresultStatus (pg_result) != PGRES_TUPLES_OK)
    {
	snprintf (pg_errstr, MAX_STRING_LEN, "PGSQL 3: %s -- Query: %s ",
		  PQerrorMessage (auth_pgsql_connection), query);
	DBG ("[mod_auth_gforge.c] PGSQL 3: %s",
	     PQerrorMessage (auth_pgsql_connection));
	PQclear (pg_result);
	PQfinish (auth_pgsql_connection);
	auth_pgsql_connection = NULL;
	return NULL;
    }

    if (PQntuples (pg_result) == 1)
    {
	val = PQgetvalue (pg_result, 0, 0);
	if (val == NULL)
	{
	    DBG ("[mod_auth_gforge.c] PGSQL 4: %s",
		 PQerrorMessage (auth_pgsql_connection));
	    PQclear (pg_result);
	    PQfinish (auth_pgsql_connection);
	    auth_pgsql_connection = NULL;
	    return NULL;
	}
	if (!(result = (char *) apr_pcalloc (r->pool, strlen (val) + 1)))
	{
	    snprintf (pg_errstr, MAX_STRING_LEN,
		      "Could not get memory for Postgres query.");
	    PQclear (pg_result);
	    PQfinish (auth_pgsql_connection);
	    auth_pgsql_connection = NULL;
	    return NULL;
	}
	strcpy (result, val);
    }

    /* ignore errors here ! */
    PQclear (pg_result);

    return result;
}
