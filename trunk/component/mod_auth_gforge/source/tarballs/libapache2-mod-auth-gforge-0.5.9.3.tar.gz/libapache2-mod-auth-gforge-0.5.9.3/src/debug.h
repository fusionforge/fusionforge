#ifndef _DEBUG_H_
#define _DEBUG_H_

#include <httpd.h>
#include <http_log.h>
#include "../lconfig.h"

// under debug mode, everything logged as an errror
// otherwise, DBG stripped out and others logged at appropriate LogLevel
#if MOD_AUTH_GFORGE_DEBUG
#define DBG(format, ...) ap_log_error(APLOG_MARK, APLOG_ERR, \
		 	0, NULL, format, ## __VA_ARGS__)
#define INFO(format, ...) ap_log_error(APLOG_MARK, APLOG_ERR, \
		 	0, NULL, format, ## __VA_ARGS__)
#define ERR(format, ...) ap_log_error(APLOG_MARK, APLOG_ERR, \
		 	0, NULL, format, ## __VA_ARGS__)
#define WRN(format, ...) ap_log_error(APLOG_MARK, APLOG_ERR, \
		 	0, NULL, format, ## __VA_ARGS__)
#else
#define DBG(format, ...)
#define INFO(format, ...) ap_log_error(APLOG_MARK, APLOG_INFO, \
		 	0, NULL, format, ## __VA_ARGS__)
#define ERR(format, ...) ap_log_error(APLOG_MARK, APLOG_ERR, \
		 	0, NULL, format, ## __VA_ARGS__)
#define WRN(format, ...) ap_log_error(APLOG_MARK, APLOG_WARNING, \
		 	0, NULL, format, ## __VA_ARGS__)
#endif


#endif
