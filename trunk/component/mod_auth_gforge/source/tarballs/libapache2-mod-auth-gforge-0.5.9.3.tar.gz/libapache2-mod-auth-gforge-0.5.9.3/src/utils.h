/*
 * utils.h
 *
 * Apache module for Gforge
 * This module provides authentication and authorization
 * in a Location supporting projects path
 *
 * @author    Francisco Gimeno <kikov @ fco-gimeno.com>
 * @date      2004-03-01
 * @see
 *
 *
 *
 */

/*
 *  Util Functions
 *
 *
 */

#ifndef _UTILS_H_
#define _UTILS_H_


#include "types.h"
#include "httpd.h"
#include "http_config.h"
#include "apacheconfig.h"


/**
 * int gforge_access_method ( int method_number )
 *
 * @desc return READ or WRITE method from the method_number
 * @param method_number Apache method number that can be obtanined
 *   by req->method_number
 */
int gforge_access_method (int method_number);

/**
 * int get_kind_from_uri ( config_auth_gforge_state *sec,
 *           request_rec *r, char * uri )
 *
 *  @desc check if we are in the groups directories, users
 *     or unknown
 *
 *  @param sec Configuration from Apache
 *  @param r   Request
 *  @param uri Uri to get the kind
 *  @return ROOT_DIR, GROUPS_DIR, USERS_DIR or UNKNOWN_DIR
 */
int get_kind_from_uri (config_auth_gforge_state * sec, request_rec * r,
		       char *uri);

/**
 * char *extract_group_from_uri ( config_auth_gforge_state *sec,
 *		request_rec *r,char *uri )
 *
 * @desc This function extract the gforge group in the uri
 *       Example: http://server/projects/project1/filename
 * -> it returns project1
 * @return The group name ( validated )
 *		   NULL if group was not found
 *
 */
char *extract_group_from_uri (config_auth_gforge_state * sec, request_rec * r,
			      char *uri);

/**
 * char *extract_user_from_uri ( config_auth_gforge_state *sec,
 *		request_rec *r,char *uri )
 *
 * @desc This function extract the user in the uri
 *       Example: http://server/users/user1/filename -> it returns user1
 *       if, First_Letter On, http://server/users/u/user1/filename -> it
 *					return user1
 * @return The user name ( validated ) in a new string
 *		   NULL if user was not found
 *
 */
char *extract_user_from_uri (config_auth_gforge_state * sec, request_rec * r,
			     char *uri);

/**
 * int is_private_dir ( config_auth_gforge_state *sec,
 *		request_rec *r, char *uri )
 *
 * @desc This function look if the uri is a private directory
 *       Example: http://server/users/user1/private/file2 -> it returns true
 * @return TRUE if it's the private dir
 *         FALSE if not
 *
 */
int is_private_dir (config_auth_gforge_state * sec, request_rec * r, char *uri);

/**
 * @func int group_contains_user ( config_auth_gforge_state *sec, const char
 *            *group, const char *user, request_rec *r)
 *
 * @desc is the User in the Group ?
 *
 * @param sec Configuration set
 * @param group Group Name
 * @param user User name
 * @param r HttpRequest_rec
 *
 */
int
group_contains_user (config_auth_gforge_state * sec, const char
		     *group, const char *user, request_rec * r);

/**
 * @func int group_active ( config_auth_gforge_state *sec, const
 *                  char group, request_rec *r)
 *
 * @desc is the Group active? It uses a cache system
 *
 * @param sec Configuration set
 * @param group Group Name
 * @param user User name
 * @param r HttpRequest_rec
 *
 * @return TRUE if active,
 *         FALSE if not
 */
int
group_active (config_auth_gforge_state * sec, const char
	      *group, request_rec * r);

/**
 * @func int user_active ( config_auth_gforge_state *sec, const
 *                char user, request_rec *r)
 *
 * @desc is the User active?. It uses a cache system
 *
 * @param sec Configuration set
 * @param user User name
 * @param r HttpRequest_rec
 *
 * @return TRUE if active,
 *         FALSE if not
 */
int
user_active (config_auth_gforge_state * sec, const char *user, request_rec * r);


/**
 * @func int is_group_public (  config_auth_gforge_state * sec, const char
 *               *group, request_rec * r )
 *
 * @desc is the group public? . It could use cache tables automatically
 *
 * @param sec Configuration Set
 * @param group Group to check
 * @param r HttpRequest
 *
 * @return TRUE if Public,
 *         FALSE if not Public
 *
 */
int
is_group_public (config_auth_gforge_state * sec, const char
		 *group, request_rec * r);

/**
 * @func int is_user_siteadmin(  config_auth_gforge_state * sec,
 *                    const char *user, request_rec * r )
 *
 * @desc Check if the user is a Site Admin. It uses a cache table if
 *       it's setup
 *
 * @param sec Configuration set
 * @param user User name
 * @param r HttpRequest_rec
 *
 * @return int, TRUE if user is siteadmin
 *              FALSE if user is not siteadmin
 **/
int
is_user_siteadmin (config_auth_gforge_state * sec, const char
		   *user, request_rec * r);

/**
 * int user_is_groupadmin (  config_auth_gforge_state *sec, const
 *     const char    *user, const char *group, request_rec *r )
 * @desc is User an admin of this group
 * @param sec Configuration Set
 * @param user The username to check
 * @param group The group to check
 * @return int, TRUE if user is group admin,
 *              FALSE if not.
 */
int
user_is_groupadmin (config_auth_gforge_state * sec, const char
		    *user, const char *group, request_rec * r);

/**
 * int user_is_member (  config_auth_gforge_state *sec, const
 *     const char    *user, const char *group, request_rec *r )
 * @desc is User a member of this group
 * @param sec Configuration Set
 * @param user The username to check
 * @param group The group to check
 * @return int, TRUE if user is group admin,
 *              FALSE if not.
 */
int
user_is_member (config_auth_gforge_state * sec, const char
		    *user, const char *group, request_rec * r);
/**
 * char * string_substitute ( char *orig, char *a, char *b
 * @desc substitute the string a by b in orig
 * @param p pool
 * @param orig The long string
 * @param a string to be substituted
 * @param b string to substitute to
 */
char *string_substitute (apr_pool_t * p, char *orig, char *a, char *b);

/**
 * char * get_clause (request_rec * r, config_auth_gforge_state * sec,
 *	    char *clause, char *uri, int access_type, char *real_group)
 *
 * @desc substitute the params in a clause string
 *
 * @desc pool The apr_pool_t to store the new string
 * @desc sec  The apache configuration set
 * @desc clause The string with the Params
 *               $G -> Group Accessed
 *               $U -> User accessing
 *		 $A -> Access Type [ READ | WRITE ]
 * @desc real_name The name of the user accessing
 * @desc real_group The name of the group accessed
 *
 * @return a new string containing the clause with the params
 *    substituted. NULL if some param couldn't be substituted.
 */
char *get_clause (apr_pool_t * pool,
		  char *clause, char *uri, int access_type, char *real_user,
		  char *real_group);
#endif
