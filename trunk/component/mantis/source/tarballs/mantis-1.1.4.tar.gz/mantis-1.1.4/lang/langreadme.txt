All the strings translations should use UTF-8 encoding now to allow
for Mantis multilingual operation. Please base your updates on
'strings_<language>.txt' files ONLY.

PLEASE NOTE:
strings_<language>_<encoding>.txt files are temporarily left here
for backward compatibility only, until we can recode them automatically.
Such a translations are considered unmaintained, and could be removed
in the future.

To still use them, please add the appropriate line to
$g_language_choices_arr (e.g. 'bulgarian-1251').

They are:

strings_bulgarian_1251.txt
strings_catalan_8859-15.txt
strings_chinese_simplified_gb2312.txt
strings_chinese_traditional_big5.txt
strings_croatian_8859-2.txt
strings_czech_8859-2.txt
strings_danish_8859-15.txt
strings_dutch_8859-15.txt
strings_estonian_8859-15.txt
strings_finnish_8859-15.txt
strings_french_8859-15.txt
strings_german_8859-1.txt
strings_hungarian_8859-2.txt
strings_icelandic_8859-1.txt
strings_italian_1252.txt
strings_japanese_euc.txt
strings_japanese_sjis.txt
strings_korean_euc-kr.txt
strings_latvian_1257.txt
strings_lithuanian_1257.txt
strings_norwegian_8859-15.txt
strings_polish_8859-2.txt
strings_portuguese_brazil_8859-1.txt
strings_portuguese_standard_8859-1.txt
strings_russian_1251.txt
strings_russian_koi8.txt
strings_serbian_8859-2.txt
strings_slovak_8859-2.txt
strings_slovene_8859-2.txt
strings_spanish_8859-15.txt
strings_swedish_8859-1.txt
strings_turkish_8859-9.txt
strings_ukrainian_1251.txt

-achumakov