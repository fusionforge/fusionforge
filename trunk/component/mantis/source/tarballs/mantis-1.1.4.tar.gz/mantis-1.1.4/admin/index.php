<html>
<head>
<title> Mantis Administration </title>
<link rel="stylesheet" type="text/css" href="admin.css" />
</head>
<body>
<table width="100%" border="0" cellspacing="0" cellpadding="0" bgcolor="#ffffff">
	<tr class="top-bar">
		<td class="links">
			&nbsp;
		</td>
		<td class="title">
			&nbsp;
		</td>
	</tr>
</table>
<br /><br />
<div align="center">
	<table width="75%"><tr><td align="center">
	<h1>Mantis Administration</h1>
	<p>Note: be sure to secure this area or remove it from your Mantis installation when you are done.  Leaving the administration area unprotected after installation leaves system information and database update capabilities open to any unauthorized person.</p>
	<p>[ <a href="check.php">Check your installation</a> ]</p>
	<p>[ <a href="upgrade_warning.php">Upgrade your installation</a> ]</p>
	<p>[ <a href="system_utils.php">System Utilities</a> ]</p>
	</td></tr></table>
</div>
</body>
</html>
