/*
 * Empty stubs for Netscape's security package.
 * Javier Kohen
 */

package netscape.security;

public final
class PrivilegeManager {
    public static void enablePrivilege(String targetStr) {
    }
    public static void revertPrivilege(String targetStr) {
    }
}
