<?php header('Location: http://db2latex.sourceforge.net/reference/rn03re13.html');?>
