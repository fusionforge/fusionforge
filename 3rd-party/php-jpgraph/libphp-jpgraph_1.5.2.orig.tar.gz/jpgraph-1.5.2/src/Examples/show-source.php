<?php highlight_file(basename(urldecode($HTTP_GET_VARS['target']))); ?>
