// Expose jQuery to the global object
window.jQuery = window.$ = jQuery;

})(window);
