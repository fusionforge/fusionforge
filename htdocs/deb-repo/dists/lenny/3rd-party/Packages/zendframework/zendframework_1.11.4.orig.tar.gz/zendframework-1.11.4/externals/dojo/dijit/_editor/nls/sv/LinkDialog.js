({
	createLinkTitle: "Länkegenskaper",
	insertImageTitle: "Bildegenskaper",
	url: "URL-adress:",
	text: "Beskrivning:",
	target: "Mål:",
	set: "Ange",
	currentWindow: "aktuellt fönster",
	parentWindow: "överordnat fönster",
	topWindow: "översta fönstret",
	newWindow: "nytt fönster"
})

