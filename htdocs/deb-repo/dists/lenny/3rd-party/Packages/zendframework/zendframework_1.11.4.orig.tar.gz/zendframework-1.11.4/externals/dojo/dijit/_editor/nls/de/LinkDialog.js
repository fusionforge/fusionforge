({
	createLinkTitle: "Linkeigenschaften",
	insertImageTitle: "Grafikeigenschaften",
	url: "URL:",
	text: "Beschreibung:",
	target: "Ziel:",
	set: "Festlegen",
	currentWindow: "Aktuelles Fenster",
	parentWindow: "Übergeordnetes Fenster",
	topWindow: "Aktives Fenster",
	newWindow: "Neues Fenster"
})

