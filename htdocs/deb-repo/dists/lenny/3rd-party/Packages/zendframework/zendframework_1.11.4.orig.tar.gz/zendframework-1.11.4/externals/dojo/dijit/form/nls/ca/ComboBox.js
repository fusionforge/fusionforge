({
		previousMessage: "Opcions anteriors",
		nextMessage: "Més opcions"
})

